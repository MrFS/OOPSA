﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdminMetro
    Inherits Syncfusion.Windows.Forms.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim ReportDataSource2 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim ReportDataSource3 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim GridBaseStyle1 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle2 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle3 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle4 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle5 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle6 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle7 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle8 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle9 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle10 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle11 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle12 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAdminMetro))
        Dim MetroColorTable1 As Syncfusion.Windows.Forms.MetroColorTable = New Syncfusion.Windows.Forms.MetroColorTable()
        Dim GridBaseStyle13 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle14 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle15 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle16 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim ReportDataSource4 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim GridBaseStyle17 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle18 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle19 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle20 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle21 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle22 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle23 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle24 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle25 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle26 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle27 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle28 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle29 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle30 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle31 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle32 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim ReportDataSource5 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim GridBaseStyle33 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle34 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle35 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle36 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle37 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle38 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle39 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim GridBaseStyle40 As Syncfusion.Windows.Forms.Grid.GridBaseStyle = New Syncfusion.Windows.Forms.Grid.GridBaseStyle()
        Dim CaptionImage1 As Syncfusion.Windows.Forms.CaptionImage = New Syncfusion.Windows.Forms.CaptionImage()
        Me.SalgsRaportBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.drift8_2016dsSalgsRapportView = New OOPSA.drift8_2016dsSalgsRapportView()
        Me.LagerRapportALLEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Drift8_2016DataSetLageroversiktALLE = New OOPSA.drift8_2016DataSetLageroversiktALLE()
        Me.VisAktiveLeieBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.drift8_2016dsVisLeieRapportView = New OOPSA.drift8_2016dsVisLeieRapportView()
        Me.VisLeieBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SalgsRaportBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.KjøpBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.drift8_2016DataSet = New OOPSA.drift8_2016DataSet()
        Me.tbAnsKund = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.tbOverview = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.TabControlAdv3 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.TabPageAdv3 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.TabControlAdv4 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.reportSalg = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.ToolStripEx7 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.reportLager = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.ReportViewer2 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.ToolStripEx8 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.reportLeie = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.ReportViewer3 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.ToolStripEx9 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.ToolStripEx1 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.FrmLagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FrmSalgToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.tbPersoner = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.GradientPanel1 = New Syncfusion.Windows.Forms.Tools.GradientPanel()
        Me.TabControlAdv5 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.tbAnsatte = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.SplitContainerAdv1 = New Syncfusion.Windows.Forms.Tools.SplitContainerAdv()
        Me.btnAnsattUpdate = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.btnChngPW = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.btnAddUsr = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.TabControlAdv6 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.TabPageAdv4 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.dgvAnsatte = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.AnsattBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.tbKunder = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.TabControlAdv1 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.tbKunderOversikt = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.btnUpdKunde = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.btnAddKunde = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.tbKundeOversikt = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.TabPageAdv15 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.dgvPrivatKunde = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.TabPageAdv16 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.dgvBedriftKunde = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.TbOppdaterKunde = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.txtBedNavn = New System.Windows.Forms.TextBox()
        Me.txtBedAdresse = New System.Windows.Forms.TextBox()
        Me.chkBedNavn = New System.Windows.Forms.CheckBox()
        Me.chkAdresse = New System.Windows.Forms.CheckBox()
        Me.txtPrivAdresse = New System.Windows.Forms.TextBox()
        Me.txtPostBed = New System.Windows.Forms.TextBox()
        Me.txtPostPriv = New System.Windows.Forms.TextBox()
        Me.chkPostNummer = New System.Windows.Forms.CheckBox()
        Me.btnOppdater = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.chkEpost = New System.Windows.Forms.CheckBox()
        Me.chkEtternavn = New System.Windows.Forms.CheckBox()
        Me.chkFornavn = New System.Windows.Forms.CheckBox()
        Me.txtEpost = New System.Windows.Forms.TextBox()
        Me.txtEtternavn = New System.Windows.Forms.TextBox()
        Me.txtFornavn = New System.Windows.Forms.TextBox()
        Me.txtKID = New System.Windows.Forms.TextBox()
        Me.lblKID = New System.Windows.Forms.Label()
        Me.btnOppdaterBedKunde = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.btnOppdaterPrivKunde = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.tbKundeEpost = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.rtbKundeEpost = New System.Windows.Forms.RichTextBox()
        Me.StatusStripEx1 = New Syncfusion.Windows.Forms.Tools.StatusStripEx()
        Me.ToolStripEx11 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.NewToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSendEpostKunde = New System.Windows.Forms.ToolStripButton()
        Me.toolstripCMBxKunder = New Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripTxtSubject = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSplitButtonEx1 = New Syncfusion.Windows.Forms.Tools.ToolStripSplitButtonEx()
        Me.FakturaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NyhetsbrevToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VareoversiktToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripEx2 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.tbSalg = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.TabControlAdv2 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.tbTextEdit = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.FontListBox1 = New Syncfusion.Windows.Forms.Tools.FontListBox()
        Me.richTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.ToolStripEx6 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.NewToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.OpenToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.SaveToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.PrintToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.CopyToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.PasteToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.txtUndo = New System.Windows.Forms.ToolStripButton()
        Me.txtRedo = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.txtFontCombo = New Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx()
        Me.txtFontSizeCombo = New Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.txtInsertImg = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.txtAlignLeft = New System.Windows.Forms.ToolStripButton()
        Me.txtAlignJust = New System.Windows.Forms.ToolStripButton()
        Me.txtAlignRight = New System.Windows.Forms.ToolStripButton()
        Me.tbUtleieOversikt = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.ButtonLeggTilLeie = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.GridDataBoundGrid1 = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.tbReporting = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.ReportViewer4 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.ToolStripEx3 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton()
        Me.tbSettings = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.tabSettings = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.TabPageAdv1 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.txtSvrPassRep = New Syncfusion.Windows.Forms.Tools.TextBoxExt()
        Me.txtSvrPass = New Syncfusion.Windows.Forms.Tools.TextBoxExt()
        Me.TxtSvrUser = New Syncfusion.Windows.Forms.Tools.TextBoxExt()
        Me.txtSvrDB = New Syncfusion.Windows.Forms.Tools.TextBoxExt()
        Me.txtServer = New Syncfusion.Windows.Forms.Tools.TextBoxExt()
        Me.lblSvrPassRep = New Syncfusion.Windows.Forms.Tools.AutoLabel()
        Me.lblSvrPass = New Syncfusion.Windows.Forms.Tools.AutoLabel()
        Me.lblSvrUser = New Syncfusion.Windows.Forms.Tools.AutoLabel()
        Me.lblDB = New Syncfusion.Windows.Forms.Tools.AutoLabel()
        Me.lblServer = New Syncfusion.Windows.Forms.Tools.AutoLabel()
        Me.toolstripDBInfo = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.tsBtnDBInfo = New System.Windows.Forms.ToolStripButton()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.rtbSQLQuery = New System.Windows.Forms.RichTextBox()
        Me.ToolStripEx10 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel()
        Me.dgvSQLQuery = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.ToolStripEx5 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.tbLager = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.TabLager = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.TabPageAdv5 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.GridDataBoundGrid4 = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.TabPageAdv6 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.GridDataBoundGrid3 = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.LagerRapportTrondheimBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Drift8_2016DataSetTrondheimLager = New OOPSA.drift8_2016DataSetTrondheimLager()
        Me.TabPageAdv7 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.GridDataBoundGrid2 = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.LagerRapportStavangerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Drift8_2016DataSetLagerRapportStavnager = New OOPSA.drift8_2016DataSetLagerRapportStavnager()
        Me.TabPageAdv2 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.ReportViewer5 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.ToolStripEx4 = New Syncfusion.Windows.Forms.Tools.ToolStripEx()
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton()
        Me.Drift82016DataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.KundeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StatusStripLabel1 = New Syncfusion.Windows.Forms.Tools.StatusStripLabel()
        Me.StatusStripProgressBar1 = New Syncfusion.Windows.Forms.Tools.StatusStripProgressBar()
        Me.StatusStripLabel2 = New Syncfusion.Windows.Forms.Tools.StatusStripLabel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.KjøpTableAdapter = New OOPSA.drift8_2016DataSetTableAdapters.KjøpTableAdapter()
        Me.AnsattTableAdapter = New OOPSA.drift8_2016DataSetTableAdapters.AnsattTableAdapter()
        Me.SpellChecker1 = New Syncfusion.Text.SpellChecker(Me.components)
        Me.SalgsRaportTableAdapter = New OOPSA.drift8_2016dsSalgsRapportViewTableAdapters.SalgsRaportTableAdapter()
        Me.Drift82016dsSalgsRapportViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SalgsRaportBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.KundeTableAdapter = New OOPSA.drift8_2016DataSetTableAdapters.KundeTableAdapter()
        Me.A_LagerTableAdapter1 = New OOPSA.drift8_2016DataSetTableAdapters.A_LagerTableAdapter()
        Me.SalgsRaportBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.LagerRapportTrondheimTableAdapter = New OOPSA.drift8_2016DataSetTrondheimLagerTableAdapters.LagerRapportTrondheimTableAdapter()
        Me.LagerRapportALLETableAdapter = New OOPSA.drift8_2016DataSetLageroversiktALLETableAdapters.LagerRapportALLETableAdapter()
        Me.LagerRapportStavangerTableAdapter = New OOPSA.drift8_2016DataSetLagerRapportStavnagerTableAdapters.LagerRapportStavangerTableAdapter()
        Me.TabPageAdv9 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.SplitContainerAdv2 = New Syncfusion.Windows.Forms.Tools.SplitContainerAdv()
        Me.ButtonAdv1 = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.ButtonAdv2 = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.ButtonAdv3 = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.TabControlAdv8 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.TabPageAdv10 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.GridDataBoundGrid5 = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.TabPageAdv11 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.TabPageAdv12 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.TabControlAdv9 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.TabPageAdv13 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer()
        Me.ButtonAdv4 = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.ButtonAdv5 = New Syncfusion.Windows.Forms.ButtonAdv()
        Me.GridDataBoundGrid6 = New Syncfusion.Windows.Forms.Grid.GridDataBoundGrid()
        Me.TabPageAdv14 = New Syncfusion.Windows.Forms.Tools.TabPageAdv()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.StatusStripEx2 = New Syncfusion.Windows.Forms.Tools.StatusStripEx()
        Me.TabControlAdv7 = New Syncfusion.Windows.Forms.Tools.TabControlAdv()
        Me.VisAnsattesSalgBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.dtSalgReportingBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VisAktiveLeieTableAdapter = New OOPSA.drift8_2016dsVisLeieRapportViewTableAdapters.VisAktiveLeieTableAdapter()
        CType(Me.SalgsRaportBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.drift8_2016dsSalgsRapportView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LagerRapportALLEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Drift8_2016DataSetLageroversiktALLE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VisAktiveLeieBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.drift8_2016dsVisLeieRapportView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VisLeieBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SalgsRaportBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KjøpBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.drift8_2016DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbAnsKund, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbAnsKund.SuspendLayout()
        Me.tbOverview.SuspendLayout()
        CType(Me.TabControlAdv3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv3.SuspendLayout()
        Me.TabPageAdv3.SuspendLayout()
        CType(Me.TabControlAdv4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv4.SuspendLayout()
        Me.reportSalg.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.reportLager.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.reportLeie.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.ToolStripEx1.SuspendLayout()
        Me.tbPersoner.SuspendLayout()
        CType(Me.GradientPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GradientPanel1.SuspendLayout()
        CType(Me.TabControlAdv5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv5.SuspendLayout()
        Me.tbAnsatte.SuspendLayout()
        CType(Me.SplitContainerAdv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainerAdv1.Panel1.SuspendLayout()
        Me.SplitContainerAdv1.Panel2.SuspendLayout()
        Me.SplitContainerAdv1.SuspendLayout()
        CType(Me.TabControlAdv6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv6.SuspendLayout()
        Me.TabPageAdv4.SuspendLayout()
        CType(Me.dgvAnsatte, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AnsattBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbKunder.SuspendLayout()
        CType(Me.TabControlAdv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv1.SuspendLayout()
        Me.tbKunderOversikt.SuspendLayout()
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.tbKundeOversikt, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbKundeOversikt.SuspendLayout()
        Me.TabPageAdv15.SuspendLayout()
        CType(Me.dgvPrivatKunde, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageAdv16.SuspendLayout()
        CType(Me.dgvBedriftKunde, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TbOppdaterKunde.SuspendLayout()
        Me.tbKundeEpost.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.ToolStripEx11.SuspendLayout()
        Me.ToolStripEx2.SuspendLayout()
        Me.tbSalg.SuspendLayout()
        CType(Me.TabControlAdv2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv2.SuspendLayout()
        Me.tbTextEdit.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.ToolStripEx6.SuspendLayout()
        Me.tbUtleieOversikt.SuspendLayout()
        CType(Me.GridDataBoundGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tbReporting.SuspendLayout()
        Me.ToolStripEx3.SuspendLayout()
        Me.tbSettings.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.tabSettings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabSettings.SuspendLayout()
        Me.TabPageAdv1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        CType(Me.txtSvrPassRep, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSvrPass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TxtSvrUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSvrDB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtServer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.toolstripDBInfo.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.ToolStripEx10.SuspendLayout()
        CType(Me.dgvSQLQuery, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStripEx5.SuspendLayout()
        Me.tbLager.SuspendLayout()
        CType(Me.TabLager, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabLager.SuspendLayout()
        Me.TabPageAdv5.SuspendLayout()
        CType(Me.GridDataBoundGrid4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageAdv6.SuspendLayout()
        CType(Me.GridDataBoundGrid3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LagerRapportTrondheimBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Drift8_2016DataSetTrondheimLager, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageAdv7.SuspendLayout()
        CType(Me.GridDataBoundGrid2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LagerRapportStavangerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Drift8_2016DataSetLagerRapportStavnager, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageAdv2.SuspendLayout()
        Me.ToolStripEx4.SuspendLayout()
        CType(Me.Drift82016DataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KundeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Drift82016dsSalgsRapportViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SalgsRaportBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SalgsRaportBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageAdv9.SuspendLayout()
        CType(Me.SplitContainerAdv2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainerAdv2.Panel1.SuspendLayout()
        Me.SplitContainerAdv2.Panel2.SuspendLayout()
        Me.SplitContainerAdv2.SuspendLayout()
        CType(Me.TabControlAdv8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv8.SuspendLayout()
        Me.TabPageAdv10.SuspendLayout()
        CType(Me.GridDataBoundGrid5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TabControlAdv9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv9.SuspendLayout()
        Me.TabPageAdv13.SuspendLayout()
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        CType(Me.GridDataBoundGrid6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPageAdv14.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.StatusStripEx2.SuspendLayout()
        CType(Me.TabControlAdv7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControlAdv7.SuspendLayout()
        CType(Me.VisAnsattesSalgBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtSalgReportingBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SalgsRaportBindingSource
        '
        Me.SalgsRaportBindingSource.DataMember = "SalgsRaport"
        Me.SalgsRaportBindingSource.DataSource = Me.drift8_2016dsSalgsRapportView
        '
        'drift8_2016dsSalgsRapportView
        '
        Me.drift8_2016dsSalgsRapportView.DataSetName = "drift8_2016dsSalgsRapportView"
        Me.drift8_2016dsSalgsRapportView.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'LagerRapportALLEBindingSource
        '
        Me.LagerRapportALLEBindingSource.DataMember = "LagerRapportALLE"
        Me.LagerRapportALLEBindingSource.DataSource = Me.Drift8_2016DataSetLageroversiktALLE
        '
        'Drift8_2016DataSetLageroversiktALLE
        '
        Me.Drift8_2016DataSetLageroversiktALLE.DataSetName = "drift8_2016DataSetLageroversiktALLE"
        Me.Drift8_2016DataSetLageroversiktALLE.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VisAktiveLeieBindingSource
        '
        Me.VisAktiveLeieBindingSource.DataMember = "VisAktiveLeie"
        Me.VisAktiveLeieBindingSource.DataSource = Me.drift8_2016dsVisLeieRapportView
        '
        'drift8_2016dsVisLeieRapportView
        '
        Me.drift8_2016dsVisLeieRapportView.DataSetName = "drift8_2016dsVisLeieRapportView"
        Me.drift8_2016dsVisLeieRapportView.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VisLeieBindingSource
        '
        Me.VisLeieBindingSource.DataMember = "VisLeie"
        '
        'SalgsRaportBindingSource2
        '
        Me.SalgsRaportBindingSource2.DataMember = "SalgsRaport"
        Me.SalgsRaportBindingSource2.DataSource = Me.drift8_2016dsSalgsRapportView
        '
        'KjøpBindingSource
        '
        Me.KjøpBindingSource.DataMember = "Kjøp"
        Me.KjøpBindingSource.DataSource = Me.drift8_2016DataSet
        '
        'drift8_2016DataSet
        '
        Me.drift8_2016DataSet.DataSetName = "drift8_2016DataSet"
        Me.drift8_2016DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'tbAnsKund
        '
        Me.tbAnsKund.ActiveTabColor = System.Drawing.Color.LightGray
        Me.tbAnsKund.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.tbAnsKund.BeforeTouchSize = New System.Drawing.Size(979, 479)
        Me.tbAnsKund.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tbAnsKund.BorderWidth = 2
        Me.tbAnsKund.Controls.Add(Me.tbOverview)
        Me.tbAnsKund.Controls.Add(Me.tbPersoner)
        Me.tbAnsKund.Controls.Add(Me.tbSalg)
        Me.tbAnsKund.Controls.Add(Me.tbSettings)
        Me.tbAnsKund.Controls.Add(Me.tbLager)
        Me.tbAnsKund.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbAnsKund.FixedSingleBorderColor = System.Drawing.SystemColors.Window
        Me.tbAnsKund.FocusOnTabClick = False
        Me.tbAnsKund.InactiveTabColor = System.Drawing.Color.Transparent
        Me.tbAnsKund.ItemSize = New System.Drawing.Size(104, 48)
        Me.tbAnsKund.Location = New System.Drawing.Point(0, 0)
        Me.tbAnsKund.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tbAnsKund.Name = "tbAnsKund"
        Me.tbAnsKund.RotateTextWhenVertical = True
        Me.tbAnsKund.ShowToolTips = True
        Me.tbAnsKund.Size = New System.Drawing.Size(979, 479)
        Me.tbAnsKund.TabIndex = 0
        Me.tbAnsKund.TabPanelBackColor = System.Drawing.Color.Transparent
        Me.tbAnsKund.TabStyle = GetType(Syncfusion.Windows.Forms.Tools.TabRendererMetro)
        Me.tbAnsKund.ThemesEnabled = True
        '
        'tbOverview
        '
        Me.tbOverview.BackColor = System.Drawing.Color.Transparent
        Me.tbOverview.Controls.Add(Me.TabControlAdv3)
        Me.tbOverview.Controls.Add(Me.ToolStripEx1)
        Me.tbOverview.Image = Global.OOPSA.My.Resources.Resources.tbOverview
        Me.tbOverview.ImageSize = New System.Drawing.Size(48, 48)
        Me.tbOverview.Location = New System.Drawing.Point(105, 2)
        Me.tbOverview.Margin = New System.Windows.Forms.Padding(2)
        Me.tbOverview.Name = "tbOverview"
        Me.tbOverview.ShowCloseButton = True
        Me.tbOverview.Size = New System.Drawing.Size(872, 475)
        Me.tbOverview.TabIndex = 1
        Me.tbOverview.ThemesEnabled = True
        '
        'TabControlAdv3
        '
        Me.TabControlAdv3.ActiveTabColor = System.Drawing.Color.White
        Me.TabControlAdv3.BeforeTouchSize = New System.Drawing.Size(872, 433)
        Me.TabControlAdv3.Controls.Add(Me.TabPageAdv3)
        Me.TabControlAdv3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlAdv3.InactiveTabColor = System.Drawing.Color.White
        Me.TabControlAdv3.ItemSize = New System.Drawing.Size(102, 48)
        Me.TabControlAdv3.Location = New System.Drawing.Point(0, 42)
        Me.TabControlAdv3.Name = "TabControlAdv3"
        Me.TabControlAdv3.Size = New System.Drawing.Size(872, 433)
        Me.TabControlAdv3.TabIndex = 1
        Me.TabControlAdv3.TabPanelBackColor = System.Drawing.Color.White
        Me.TabControlAdv3.ThemesEnabled = True
        '
        'TabPageAdv3
        '
        Me.TabPageAdv3.Controls.Add(Me.TabControlAdv4)
        Me.TabPageAdv3.Image = Global.OOPSA.My.Resources.Resources.tbReport
        Me.TabPageAdv3.ImageSize = New System.Drawing.Size(32, 32)
        Me.TabPageAdv3.Location = New System.Drawing.Point(3, 53)
        Me.TabPageAdv3.Name = "TabPageAdv3"
        Me.TabPageAdv3.ShowCloseButton = True
        Me.TabPageAdv3.Size = New System.Drawing.Size(865, 376)
        Me.TabPageAdv3.TabIndex = 1
        Me.TabPageAdv3.Text = "Rapporter"
        Me.TabPageAdv3.ThemesEnabled = True
        '
        'TabControlAdv4
        '
        Me.TabControlAdv4.ActiveTabColor = System.Drawing.Color.White
        Me.TabControlAdv4.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.TabControlAdv4.BeforeTouchSize = New System.Drawing.Size(865, 376)
        Me.TabControlAdv4.Controls.Add(Me.reportSalg)
        Me.TabControlAdv4.Controls.Add(Me.reportLager)
        Me.TabControlAdv4.Controls.Add(Me.reportLeie)
        Me.TabControlAdv4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlAdv4.InactiveTabColor = System.Drawing.Color.White
        Me.TabControlAdv4.Location = New System.Drawing.Point(0, 0)
        Me.TabControlAdv4.Name = "TabControlAdv4"
        Me.TabControlAdv4.RotateTextWhenVertical = True
        Me.TabControlAdv4.Size = New System.Drawing.Size(865, 376)
        Me.TabControlAdv4.TabIndex = 0
        Me.TabControlAdv4.TabPanelBackColor = System.Drawing.Color.White
        Me.TabControlAdv4.ThemesEnabled = True
        '
        'reportSalg
        '
        Me.reportSalg.Controls.Add(Me.Panel5)
        Me.reportSalg.Controls.Add(Me.ToolStripEx7)
        Me.reportSalg.Image = Global.OOPSA.My.Resources.Resources.tbSalg
        Me.reportSalg.ImageSize = New System.Drawing.Size(32, 32)
        Me.reportSalg.Location = New System.Drawing.Point(48, 3)
        Me.reportSalg.Name = "reportSalg"
        Me.reportSalg.ShowCloseButton = True
        Me.reportSalg.Size = New System.Drawing.Size(813, 369)
        Me.reportSalg.TabIndex = 1
        Me.reportSalg.ThemesEnabled = True
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.ReportViewer1)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(0, 40)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(813, 329)
        Me.Panel5.TabIndex = 1
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "dsSalgsRapport"
        ReportDataSource1.Value = Me.SalgsRaportBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "OOPSA.SalgsRapport.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(813, 329)
        Me.ReportViewer1.TabIndex = 0
        '
        'ToolStripEx7
        '
        Me.ToolStripEx7.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx7.Image = Nothing
        Me.ToolStripEx7.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx7.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx7.Name = "ToolStripEx7"
        Me.ToolStripEx7.Office12Mode = False
        Me.ToolStripEx7.Size = New System.Drawing.Size(813, 40)
        Me.ToolStripEx7.TabIndex = 0
        Me.ToolStripEx7.Text = "Salgsrapporter"
        Me.ToolStripEx7.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'reportLager
        '
        Me.reportLager.Controls.Add(Me.Panel8)
        Me.reportLager.Controls.Add(Me.ToolStripEx8)
        Me.reportLager.Image = Global.OOPSA.My.Resources.Resources.tbLager
        Me.reportLager.ImageSize = New System.Drawing.Size(32, 32)
        Me.reportLager.Location = New System.Drawing.Point(48, 3)
        Me.reportLager.Name = "reportLager"
        Me.reportLager.ShowCloseButton = True
        Me.reportLager.Size = New System.Drawing.Size(813, 369)
        Me.reportLager.TabIndex = 2
        Me.reportLager.ThemesEnabled = True
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.ReportViewer2)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(0, 40)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(813, 329)
        Me.Panel8.TabIndex = 2
        '
        'ReportViewer2
        '
        Me.ReportViewer2.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource2.Name = "LagerRapport"
        ReportDataSource2.Value = Me.LagerRapportALLEBindingSource
        Me.ReportViewer2.LocalReport.DataSources.Add(ReportDataSource2)
        Me.ReportViewer2.LocalReport.ReportEmbeddedResource = "OOPSA.LagerRapport.rdlc"
        Me.ReportViewer2.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer2.Name = "ReportViewer2"
        Me.ReportViewer2.Size = New System.Drawing.Size(813, 329)
        Me.ReportViewer2.TabIndex = 0
        '
        'ToolStripEx8
        '
        Me.ToolStripEx8.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx8.Image = Nothing
        Me.ToolStripEx8.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx8.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx8.Name = "ToolStripEx8"
        Me.ToolStripEx8.Office12Mode = False
        Me.ToolStripEx8.Size = New System.Drawing.Size(813, 40)
        Me.ToolStripEx8.TabIndex = 1
        Me.ToolStripEx8.Text = "Lagerrapporter"
        Me.ToolStripEx8.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'reportLeie
        '
        Me.reportLeie.Controls.Add(Me.Panel9)
        Me.reportLeie.Controls.Add(Me.ToolStripEx9)
        Me.reportLeie.Image = Global.OOPSA.My.Resources.Resources.tbRent
        Me.reportLeie.ImageSize = New System.Drawing.Size(32, 32)
        Me.reportLeie.Location = New System.Drawing.Point(48, 3)
        Me.reportLeie.Name = "reportLeie"
        Me.reportLeie.ShowCloseButton = True
        Me.reportLeie.Size = New System.Drawing.Size(813, 369)
        Me.reportLeie.TabIndex = 3
        Me.reportLeie.ThemesEnabled = True
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.ReportViewer3)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel9.Location = New System.Drawing.Point(0, 40)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(813, 329)
        Me.Panel9.TabIndex = 2
        '
        'ReportViewer3
        '
        Me.ReportViewer3.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource3.Name = "LagerRapport"
        ReportDataSource3.Value = Me.VisAktiveLeieBindingSource
        Me.ReportViewer3.LocalReport.DataSources.Add(ReportDataSource3)
        Me.ReportViewer3.LocalReport.ReportEmbeddedResource = "OOPSA.LeieRapport.rdlc"
        Me.ReportViewer3.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer3.Name = "ReportViewer3"
        Me.ReportViewer3.Size = New System.Drawing.Size(813, 329)
        Me.ReportViewer3.TabIndex = 0
        '
        'ToolStripEx9
        '
        Me.ToolStripEx9.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx9.Image = Nothing
        Me.ToolStripEx9.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx9.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx9.Name = "ToolStripEx9"
        Me.ToolStripEx9.Office12Mode = False
        Me.ToolStripEx9.Size = New System.Drawing.Size(813, 40)
        Me.ToolStripEx9.TabIndex = 1
        Me.ToolStripEx9.Text = "Utleierapporter"
        Me.ToolStripEx9.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripEx1
        '
        Me.ToolStripEx1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStripEx1.Image = Nothing
        Me.ToolStripEx1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripDropDownButton1, Me.ToolStripButton2})
        Me.ToolStripEx1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx1.Name = "ToolStripEx1"
        Me.ToolStripEx1.Office12Mode = False
        Me.ToolStripEx1.Size = New System.Drawing.Size(872, 42)
        Me.ToolStripEx1.TabIndex = 0
        Me.ToolStripEx1.Text = "Oversikt"
        Me.ToolStripEx1.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FrmLagerToolStripMenuItem, Me.FrmSalgToolStripMenuItem})
        Me.ToolStripDropDownButton1.Image = Global.OOPSA.My.Resources.Resources.loginLeaf
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(73, 24)
        Me.ToolStripDropDownButton1.Text = "Forms"
        '
        'FrmLagerToolStripMenuItem
        '
        Me.FrmLagerToolStripMenuItem.Name = "FrmLagerToolStripMenuItem"
        Me.FrmLagerToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.FrmLagerToolStripMenuItem.Text = "frmLager"
        '
        'FrmSalgToolStripMenuItem
        '
        Me.FrmSalgToolStripMenuItem.Name = "FrmSalgToolStripMenuItem"
        Me.FrmSalgToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.FrmSalgToolStripMenuItem.Text = "frmSalg"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton2.Image = Global.OOPSA.My.Resources.Resources.tbLogout
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(72, 24)
        Me.ToolStripButton2.Text = "Logg ut"
        '
        'tbPersoner
        '
        Me.tbPersoner.Controls.Add(Me.GradientPanel1)
        Me.tbPersoner.Controls.Add(Me.ToolStripEx2)
        Me.tbPersoner.Image = Global.OOPSA.My.Resources.Resources.tbAnsatte
        Me.tbPersoner.ImageSize = New System.Drawing.Size(48, 48)
        Me.tbPersoner.Location = New System.Drawing.Point(105, 2)
        Me.tbPersoner.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tbPersoner.Name = "tbPersoner"
        Me.tbPersoner.ShowCloseButton = True
        Me.tbPersoner.Size = New System.Drawing.Size(872, 475)
        Me.tbPersoner.TabIndex = 2
        Me.tbPersoner.ThemesEnabled = True
        '
        'GradientPanel1
        '
        Me.GradientPanel1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.GradientPanel1.Controls.Add(Me.TabControlAdv5)
        Me.GradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GradientPanel1.Location = New System.Drawing.Point(0, 42)
        Me.GradientPanel1.Name = "GradientPanel1"
        Me.GradientPanel1.Size = New System.Drawing.Size(872, 433)
        Me.GradientPanel1.TabIndex = 5
        '
        'TabControlAdv5
        '
        Me.TabControlAdv5.BeforeTouchSize = New System.Drawing.Size(872, 433)
        Me.TabControlAdv5.Controls.Add(Me.tbAnsatte)
        Me.TabControlAdv5.Controls.Add(Me.tbKunder)
        Me.TabControlAdv5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlAdv5.Location = New System.Drawing.Point(0, 0)
        Me.TabControlAdv5.Name = "TabControlAdv5"
        Me.TabControlAdv5.Size = New System.Drawing.Size(872, 433)
        Me.TabControlAdv5.TabIndex = 0
        Me.TabControlAdv5.ThemesEnabled = True
        '
        'tbAnsatte
        '
        Me.tbAnsatte.Controls.Add(Me.SplitContainerAdv1)
        Me.tbAnsatte.Image = Nothing
        Me.tbAnsatte.ImageSize = New System.Drawing.Size(16, 16)
        Me.tbAnsatte.Location = New System.Drawing.Point(3, 35)
        Me.tbAnsatte.Name = "tbAnsatte"
        Me.tbAnsatte.ShowCloseButton = True
        Me.tbAnsatte.Size = New System.Drawing.Size(865, 394)
        Me.tbAnsatte.TabIndex = 1
        Me.tbAnsatte.Text = "Ansatte"
        Me.tbAnsatte.ThemesEnabled = True
        '
        'SplitContainerAdv1
        '
        Me.SplitContainerAdv1.BeforeTouchSize = 7
        Me.SplitContainerAdv1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainerAdv1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainerAdv1.Name = "SplitContainerAdv1"
        '
        'SplitContainerAdv1.Panel1
        '
        Me.SplitContainerAdv1.Panel1.Controls.Add(Me.btnAnsattUpdate)
        Me.SplitContainerAdv1.Panel1.Controls.Add(Me.btnChngPW)
        Me.SplitContainerAdv1.Panel1.Controls.Add(Me.btnAddUsr)
        '
        'SplitContainerAdv1.Panel2
        '
        Me.SplitContainerAdv1.Panel2.Controls.Add(Me.TabControlAdv6)
        Me.SplitContainerAdv1.Size = New System.Drawing.Size(865, 394)
        Me.SplitContainerAdv1.SplitterDistance = 173
        Me.SplitContainerAdv1.TabIndex = 4
        Me.SplitContainerAdv1.Text = "SplitContainerAdv1"
        '
        'btnAnsattUpdate
        '
        Me.btnAnsattUpdate.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnAnsattUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnAnsattUpdate.BeforeTouchSize = New System.Drawing.Size(173, 60)
        Me.btnAnsattUpdate.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAnsattUpdate.ForeColor = System.Drawing.Color.White
        Me.btnAnsattUpdate.IsBackStageButton = False
        Me.btnAnsattUpdate.Location = New System.Drawing.Point(0, 120)
        Me.btnAnsattUpdate.Name = "btnAnsattUpdate"
        Me.btnAnsattUpdate.Size = New System.Drawing.Size(173, 60)
        Me.btnAnsattUpdate.TabIndex = 4
        Me.btnAnsattUpdate.Text = "Oppdater Ansatte"
        Me.btnAnsattUpdate.UseVisualStyle = True
        '
        'btnChngPW
        '
        Me.btnChngPW.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnChngPW.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnChngPW.BeforeTouchSize = New System.Drawing.Size(173, 60)
        Me.btnChngPW.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnChngPW.ForeColor = System.Drawing.Color.White
        Me.btnChngPW.IsBackStageButton = False
        Me.btnChngPW.Location = New System.Drawing.Point(0, 60)
        Me.btnChngPW.Name = "btnChngPW"
        Me.btnChngPW.Size = New System.Drawing.Size(173, 60)
        Me.btnChngPW.TabIndex = 3
        Me.btnChngPW.Text = "Endre passord " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for ansatt"
        Me.btnChngPW.UseVisualStyle = True
        '
        'btnAddUsr
        '
        Me.btnAddUsr.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnAddUsr.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnAddUsr.BeforeTouchSize = New System.Drawing.Size(173, 60)
        Me.btnAddUsr.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAddUsr.ForeColor = System.Drawing.Color.White
        Me.btnAddUsr.IsBackStageButton = False
        Me.btnAddUsr.Location = New System.Drawing.Point(0, 0)
        Me.btnAddUsr.Name = "btnAddUsr"
        Me.btnAddUsr.Size = New System.Drawing.Size(173, 60)
        Me.btnAddUsr.TabIndex = 2
        Me.btnAddUsr.Text = "Legg til ansatt"
        Me.btnAddUsr.UseVisualStyle = True
        '
        'TabControlAdv6
        '
        Me.TabControlAdv6.BeforeTouchSize = New System.Drawing.Size(685, 394)
        Me.TabControlAdv6.Controls.Add(Me.TabPageAdv4)
        Me.TabControlAdv6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlAdv6.Location = New System.Drawing.Point(0, 0)
        Me.TabControlAdv6.Name = "TabControlAdv6"
        Me.TabControlAdv6.Size = New System.Drawing.Size(685, 394)
        Me.TabControlAdv6.TabIndex = 2
        Me.TabControlAdv6.ThemesEnabled = True
        '
        'TabPageAdv4
        '
        Me.TabPageAdv4.Controls.Add(Me.dgvAnsatte)
        Me.TabPageAdv4.Image = Nothing
        Me.TabPageAdv4.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv4.Location = New System.Drawing.Point(3, 35)
        Me.TabPageAdv4.Name = "TabPageAdv4"
        Me.TabPageAdv4.ShowCloseButton = True
        Me.TabPageAdv4.Size = New System.Drawing.Size(678, 355)
        Me.TabPageAdv4.TabIndex = 1
        Me.TabPageAdv4.Text = "Oversikt ansatte"
        Me.TabPageAdv4.ThemesEnabled = True
        '
        'dgvAnsatte
        '
        Me.dgvAnsatte.AllowDragSelectedCols = True
        Me.dgvAnsatte.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle1.Name = "Column Header"
        GridBaseStyle1.StyleInfo.BaseStyle = "Header"
        GridBaseStyle1.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle1.StyleInfo.Enabled = False
        GridBaseStyle1.StyleInfo.Font.Bold = True
        GridBaseStyle1.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle2.Name = "Header"
        GridBaseStyle2.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle2.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle2.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle2.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle2.StyleInfo.CellType = "Header"
        GridBaseStyle2.StyleInfo.Font.Bold = True
        GridBaseStyle2.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle2.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle3.Name = "Standard"
        GridBaseStyle3.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle3.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle3.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle4.Name = "Row Header"
        GridBaseStyle4.StyleInfo.BaseStyle = "Header"
        GridBaseStyle4.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle4.StyleInfo.Enabled = True
        GridBaseStyle4.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.dgvAnsatte.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle1, GridBaseStyle2, GridBaseStyle3, GridBaseStyle4})
        Me.dgvAnsatte.DataMember = ""
        Me.dgvAnsatte.DataSource = Me.AnsattBindingSource
        Me.dgvAnsatte.DefaultRowHeight = 20
        Me.dgvAnsatte.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvAnsatte.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.dgvAnsatte.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.dgvAnsatte.Location = New System.Drawing.Point(0, 0)
        Me.dgvAnsatte.MetroScrollBars = True
        Me.dgvAnsatte.Name = "dgvAnsatte"
        Me.dgvAnsatte.OptimizeInsertRemoveCells = True
        Me.dgvAnsatte.Properties.ForceImmediateRepaint = False
        Me.dgvAnsatte.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.dgvAnsatte.Properties.MarkColHeader = False
        Me.dgvAnsatte.Properties.MarkRowHeader = False
        Me.dgvAnsatte.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.dgvAnsatte.Size = New System.Drawing.Size(678, 355)
        Me.dgvAnsatte.SmartSizeBox = False
        Me.dgvAnsatte.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.dgvAnsatte.TabIndex = 1
        Me.dgvAnsatte.Text = "GridDataBoundGrid1"
        Me.dgvAnsatte.ThemesEnabled = True
        Me.dgvAnsatte.UseListChangedEvent = True
        Me.dgvAnsatte.UseRightToLeftCompatibleTextBox = True
        '
        'AnsattBindingSource
        '
        Me.AnsattBindingSource.DataMember = "Ansatt"
        Me.AnsattBindingSource.DataSource = Me.drift8_2016DataSet
        '
        'tbKunder
        '
        Me.tbKunder.Controls.Add(Me.TabControlAdv1)
        Me.tbKunder.Image = Nothing
        Me.tbKunder.ImageSize = New System.Drawing.Size(16, 16)
        Me.tbKunder.Location = New System.Drawing.Point(3, 35)
        Me.tbKunder.Name = "tbKunder"
        Me.tbKunder.ShowCloseButton = True
        Me.tbKunder.Size = New System.Drawing.Size(865, 394)
        Me.tbKunder.TabIndex = 2
        Me.tbKunder.Text = "Kunder"
        Me.tbKunder.ThemesEnabled = True
        '
        'TabControlAdv1
        '
        Me.TabControlAdv1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.TabControlAdv1.BeforeTouchSize = New System.Drawing.Size(865, 394)
        Me.TabControlAdv1.Controls.Add(Me.tbKunderOversikt)
        Me.TabControlAdv1.Controls.Add(Me.tbKundeEpost)
        Me.TabControlAdv1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlAdv1.FocusOnTabClick = False
        Me.TabControlAdv1.Location = New System.Drawing.Point(0, 0)
        Me.TabControlAdv1.Name = "TabControlAdv1"
        Me.TabControlAdv1.Size = New System.Drawing.Size(865, 394)
        Me.TabControlAdv1.TabIndex = 0
        Me.TabControlAdv1.ThemesEnabled = True
        '
        'tbKunderOversikt
        '
        Me.tbKunderOversikt.Controls.Add(Me.SplitContainer3)
        Me.tbKunderOversikt.Image = Nothing
        Me.tbKunderOversikt.ImageSize = New System.Drawing.Size(16, 16)
        Me.tbKunderOversikt.Location = New System.Drawing.Point(38, 3)
        Me.tbKunderOversikt.Name = "tbKunderOversikt"
        Me.tbKunderOversikt.ShowCloseButton = True
        Me.tbKunderOversikt.Size = New System.Drawing.Size(823, 387)
        Me.tbKunderOversikt.TabIndex = 1
        Me.tbKunderOversikt.Text = "Kunder"
        Me.tbKunderOversikt.ThemesEnabled = True
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.btnUpdKunde)
        Me.SplitContainer3.Panel1.Controls.Add(Me.btnAddKunde)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.tbKundeOversikt)
        Me.SplitContainer3.Size = New System.Drawing.Size(823, 387)
        Me.SplitContainer3.SplitterDistance = 225
        Me.SplitContainer3.TabIndex = 0
        '
        'btnUpdKunde
        '
        Me.btnUpdKunde.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnUpdKunde.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnUpdKunde.BeforeTouchSize = New System.Drawing.Size(225, 60)
        Me.btnUpdKunde.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnUpdKunde.ForeColor = System.Drawing.Color.White
        Me.btnUpdKunde.IsBackStageButton = False
        Me.btnUpdKunde.Location = New System.Drawing.Point(0, 60)
        Me.btnUpdKunde.Name = "btnUpdKunde"
        Me.btnUpdKunde.Size = New System.Drawing.Size(225, 60)
        Me.btnUpdKunde.TabIndex = 4
        Me.btnUpdKunde.Text = "Oppdater Kunde"
        Me.btnUpdKunde.UseVisualStyle = True
        '
        'btnAddKunde
        '
        Me.btnAddKunde.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnAddKunde.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnAddKunde.BeforeTouchSize = New System.Drawing.Size(225, 60)
        Me.btnAddKunde.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAddKunde.ForeColor = System.Drawing.Color.White
        Me.btnAddKunde.IsBackStageButton = False
        Me.btnAddKunde.Location = New System.Drawing.Point(0, 0)
        Me.btnAddKunde.Name = "btnAddKunde"
        Me.btnAddKunde.Size = New System.Drawing.Size(225, 60)
        Me.btnAddKunde.TabIndex = 3
        Me.btnAddKunde.Text = "Legg til ny kunde"
        Me.btnAddKunde.UseVisualStyle = True
        '
        'tbKundeOversikt
        '
        Me.tbKundeOversikt.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.tbKundeOversikt.BeforeTouchSize = New System.Drawing.Size(594, 387)
        Me.tbKundeOversikt.Controls.Add(Me.TabPageAdv15)
        Me.tbKundeOversikt.Controls.Add(Me.TabPageAdv16)
        Me.tbKundeOversikt.Controls.Add(Me.TbOppdaterKunde)
        Me.tbKundeOversikt.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbKundeOversikt.Location = New System.Drawing.Point(0, 0)
        Me.tbKundeOversikt.Name = "tbKundeOversikt"
        Me.tbKundeOversikt.Size = New System.Drawing.Size(594, 387)
        Me.tbKundeOversikt.TabIndex = 0
        Me.tbKundeOversikt.ThemesEnabled = True
        '
        'TabPageAdv15
        '
        Me.TabPageAdv15.Controls.Add(Me.dgvPrivatKunde)
        Me.TabPageAdv15.Image = Global.OOPSA.My.Resources.Resources.tbKundeBedrift
        Me.TabPageAdv15.ImageSize = New System.Drawing.Size(32, 32)
        Me.TabPageAdv15.Location = New System.Drawing.Point(46, 3)
        Me.TabPageAdv15.Name = "TabPageAdv15"
        Me.TabPageAdv15.ShowCloseButton = True
        Me.TabPageAdv15.Size = New System.Drawing.Size(544, 380)
        Me.TabPageAdv15.TabIndex = 1
        Me.TabPageAdv15.ThemesEnabled = True
        '
        'dgvPrivatKunde
        '
        Me.dgvPrivatKunde.AllowDragSelectedCols = True
        Me.dgvPrivatKunde.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle5.Name = "Column Header"
        GridBaseStyle5.StyleInfo.BaseStyle = "Header"
        GridBaseStyle5.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle5.StyleInfo.Enabled = False
        GridBaseStyle5.StyleInfo.Font.Bold = True
        GridBaseStyle5.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle6.Name = "Header"
        GridBaseStyle6.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle6.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle6.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle6.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle6.StyleInfo.CellType = "Header"
        GridBaseStyle6.StyleInfo.Font.Bold = True
        GridBaseStyle6.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle6.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle7.Name = "Standard"
        GridBaseStyle7.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle7.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle7.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle8.Name = "Row Header"
        GridBaseStyle8.StyleInfo.BaseStyle = "Header"
        GridBaseStyle8.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle8.StyleInfo.Enabled = True
        GridBaseStyle8.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.dgvPrivatKunde.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle5, GridBaseStyle6, GridBaseStyle7, GridBaseStyle8})
        Me.dgvPrivatKunde.DefaultRowHeight = 20
        Me.dgvPrivatKunde.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvPrivatKunde.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.dgvPrivatKunde.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.dgvPrivatKunde.Location = New System.Drawing.Point(0, 0)
        Me.dgvPrivatKunde.MetroScrollBars = True
        Me.dgvPrivatKunde.Name = "dgvPrivatKunde"
        Me.dgvPrivatKunde.OptimizeInsertRemoveCells = True
        Me.dgvPrivatKunde.Properties.ForceImmediateRepaint = False
        Me.dgvPrivatKunde.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.dgvPrivatKunde.Properties.MarkColHeader = False
        Me.dgvPrivatKunde.Properties.MarkRowHeader = False
        Me.dgvPrivatKunde.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.dgvPrivatKunde.Size = New System.Drawing.Size(544, 380)
        Me.dgvPrivatKunde.SmartSizeBox = False
        Me.dgvPrivatKunde.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.dgvPrivatKunde.TabIndex = 0
        Me.dgvPrivatKunde.Text = "GridDataBoundGrid7"
        Me.dgvPrivatKunde.ThemesEnabled = True
        Me.dgvPrivatKunde.UseListChangedEvent = True
        Me.dgvPrivatKunde.UseRightToLeftCompatibleTextBox = True
        '
        'TabPageAdv16
        '
        Me.TabPageAdv16.Controls.Add(Me.dgvBedriftKunde)
        Me.TabPageAdv16.Image = Global.OOPSA.My.Resources.Resources.tbKundePrivat
        Me.TabPageAdv16.ImageSize = New System.Drawing.Size(32, 32)
        Me.TabPageAdv16.Location = New System.Drawing.Point(46, 3)
        Me.TabPageAdv16.Name = "TabPageAdv16"
        Me.TabPageAdv16.ShowCloseButton = True
        Me.TabPageAdv16.Size = New System.Drawing.Size(544, 380)
        Me.TabPageAdv16.TabIndex = 2
        Me.TabPageAdv16.ThemesEnabled = True
        '
        'dgvBedriftKunde
        '
        Me.dgvBedriftKunde.AllowDragSelectedCols = True
        Me.dgvBedriftKunde.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle9.Name = "Column Header"
        GridBaseStyle9.StyleInfo.BaseStyle = "Header"
        GridBaseStyle9.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle9.StyleInfo.Enabled = False
        GridBaseStyle9.StyleInfo.Font.Bold = True
        GridBaseStyle9.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle10.Name = "Header"
        GridBaseStyle10.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle10.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle10.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle10.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle10.StyleInfo.CellType = "Header"
        GridBaseStyle10.StyleInfo.Font.Bold = True
        GridBaseStyle10.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle10.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle11.Name = "Standard"
        GridBaseStyle11.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle11.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle11.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle12.Name = "Row Header"
        GridBaseStyle12.StyleInfo.BaseStyle = "Header"
        GridBaseStyle12.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle12.StyleInfo.Enabled = True
        GridBaseStyle12.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.dgvBedriftKunde.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle9, GridBaseStyle10, GridBaseStyle11, GridBaseStyle12})
        Me.dgvBedriftKunde.DefaultRowHeight = 20
        Me.dgvBedriftKunde.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvBedriftKunde.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.dgvBedriftKunde.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.dgvBedriftKunde.Location = New System.Drawing.Point(0, 0)
        Me.dgvBedriftKunde.MetroScrollBars = True
        Me.dgvBedriftKunde.Name = "dgvBedriftKunde"
        Me.dgvBedriftKunde.OptimizeInsertRemoveCells = True
        Me.dgvBedriftKunde.Properties.ForceImmediateRepaint = False
        Me.dgvBedriftKunde.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.dgvBedriftKunde.Properties.MarkColHeader = False
        Me.dgvBedriftKunde.Properties.MarkRowHeader = False
        Me.dgvBedriftKunde.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.dgvBedriftKunde.Size = New System.Drawing.Size(544, 380)
        Me.dgvBedriftKunde.SmartSizeBox = False
        Me.dgvBedriftKunde.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.dgvBedriftKunde.TabIndex = 0
        Me.dgvBedriftKunde.Text = "GridDataBoundGrid8"
        Me.dgvBedriftKunde.ThemesEnabled = True
        Me.dgvBedriftKunde.UseListChangedEvent = True
        Me.dgvBedriftKunde.UseRightToLeftCompatibleTextBox = True
        '
        'TbOppdaterKunde
        '
        Me.TbOppdaterKunde.Controls.Add(Me.txtBedNavn)
        Me.TbOppdaterKunde.Controls.Add(Me.txtBedAdresse)
        Me.TbOppdaterKunde.Controls.Add(Me.chkBedNavn)
        Me.TbOppdaterKunde.Controls.Add(Me.chkAdresse)
        Me.TbOppdaterKunde.Controls.Add(Me.txtPrivAdresse)
        Me.TbOppdaterKunde.Controls.Add(Me.txtPostBed)
        Me.TbOppdaterKunde.Controls.Add(Me.txtPostPriv)
        Me.TbOppdaterKunde.Controls.Add(Me.chkPostNummer)
        Me.TbOppdaterKunde.Controls.Add(Me.btnOppdater)
        Me.TbOppdaterKunde.Controls.Add(Me.chkEpost)
        Me.TbOppdaterKunde.Controls.Add(Me.chkEtternavn)
        Me.TbOppdaterKunde.Controls.Add(Me.chkFornavn)
        Me.TbOppdaterKunde.Controls.Add(Me.txtEpost)
        Me.TbOppdaterKunde.Controls.Add(Me.txtEtternavn)
        Me.TbOppdaterKunde.Controls.Add(Me.txtFornavn)
        Me.TbOppdaterKunde.Controls.Add(Me.txtKID)
        Me.TbOppdaterKunde.Controls.Add(Me.lblKID)
        Me.TbOppdaterKunde.Controls.Add(Me.btnOppdaterBedKunde)
        Me.TbOppdaterKunde.Controls.Add(Me.btnOppdaterPrivKunde)
        Me.TbOppdaterKunde.Image = Global.OOPSA.My.Resources.Resources.txtSave
        Me.TbOppdaterKunde.ImageSize = New System.Drawing.Size(32, 32)
        Me.TbOppdaterKunde.Location = New System.Drawing.Point(46, 3)
        Me.TbOppdaterKunde.Name = "TbOppdaterKunde"
        Me.TbOppdaterKunde.ShowCloseButton = True
        Me.TbOppdaterKunde.Size = New System.Drawing.Size(544, 380)
        Me.TbOppdaterKunde.TabIndex = 3
        Me.TbOppdaterKunde.TabVisible = False
        Me.TbOppdaterKunde.ThemesEnabled = True
        '
        'txtBedNavn
        '
        Me.txtBedNavn.Location = New System.Drawing.Point(421, 185)
        Me.txtBedNavn.Name = "txtBedNavn"
        Me.txtBedNavn.Size = New System.Drawing.Size(100, 29)
        Me.txtBedNavn.TabIndex = 23
        Me.txtBedNavn.Visible = False
        '
        'txtBedAdresse
        '
        Me.txtBedAdresse.Location = New System.Drawing.Point(421, 137)
        Me.txtBedAdresse.Name = "txtBedAdresse"
        Me.txtBedAdresse.Size = New System.Drawing.Size(100, 29)
        Me.txtBedAdresse.TabIndex = 22
        Me.txtBedAdresse.Visible = False
        '
        'chkBedNavn
        '
        Me.chkBedNavn.AutoSize = True
        Me.chkBedNavn.Location = New System.Drawing.Point(280, 189)
        Me.chkBedNavn.Name = "chkBedNavn"
        Me.chkBedNavn.Size = New System.Drawing.Size(116, 25)
        Me.chkBedNavn.TabIndex = 21
        Me.chkBedNavn.Text = "Bedriftsnavn"
        Me.chkBedNavn.UseVisualStyleBackColor = True
        Me.chkBedNavn.Visible = False
        '
        'chkAdresse
        '
        Me.chkAdresse.AutoSize = True
        Me.chkAdresse.Location = New System.Drawing.Point(280, 139)
        Me.chkAdresse.Name = "chkAdresse"
        Me.chkAdresse.Size = New System.Drawing.Size(84, 25)
        Me.chkAdresse.TabIndex = 19
        Me.chkAdresse.Text = "Adresse"
        Me.chkAdresse.UseVisualStyleBackColor = True
        Me.chkAdresse.Visible = False
        '
        'txtPrivAdresse
        '
        Me.txtPrivAdresse.Location = New System.Drawing.Point(421, 137)
        Me.txtPrivAdresse.Name = "txtPrivAdresse"
        Me.txtPrivAdresse.Size = New System.Drawing.Size(100, 29)
        Me.txtPrivAdresse.TabIndex = 18
        Me.txtPrivAdresse.Visible = False
        '
        'txtPostBed
        '
        Me.txtPostBed.Location = New System.Drawing.Point(144, 283)
        Me.txtPostBed.Name = "txtPostBed"
        Me.txtPostBed.Size = New System.Drawing.Size(116, 29)
        Me.txtPostBed.TabIndex = 17
        Me.txtPostBed.Visible = False
        '
        'txtPostPriv
        '
        Me.txtPostPriv.Location = New System.Drawing.Point(144, 283)
        Me.txtPostPriv.Name = "txtPostPriv"
        Me.txtPostPriv.Size = New System.Drawing.Size(116, 29)
        Me.txtPostPriv.TabIndex = 16
        Me.txtPostPriv.Visible = False
        '
        'chkPostNummer
        '
        Me.chkPostNummer.AutoSize = True
        Me.chkPostNummer.Location = New System.Drawing.Point(16, 285)
        Me.chkPostNummer.Name = "chkPostNummer"
        Me.chkPostNummer.Size = New System.Drawing.Size(122, 25)
        Me.chkPostNummer.TabIndex = 15
        Me.chkPostNummer.Text = "Post nummer"
        Me.chkPostNummer.UseVisualStyleBackColor = True
        Me.chkPostNummer.Visible = False
        '
        'btnOppdater
        '
        Me.btnOppdater.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnOppdater.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnOppdater.BeforeTouchSize = New System.Drawing.Size(169, 54)
        Me.btnOppdater.ForeColor = System.Drawing.Color.White
        Me.btnOppdater.IsBackStageButton = False
        Me.btnOppdater.Location = New System.Drawing.Point(369, 325)
        Me.btnOppdater.Name = "btnOppdater"
        Me.btnOppdater.Size = New System.Drawing.Size(169, 54)
        Me.btnOppdater.TabIndex = 14
        Me.btnOppdater.Text = "Utfør oppdatering"
        Me.btnOppdater.UseVisualStyle = True
        '
        'chkEpost
        '
        Me.chkEpost.AutoSize = True
        Me.chkEpost.Location = New System.Drawing.Point(16, 235)
        Me.chkEpost.Name = "chkEpost"
        Me.chkEpost.Size = New System.Drawing.Size(67, 25)
        Me.chkEpost.TabIndex = 13
        Me.chkEpost.Text = "Epost"
        Me.chkEpost.UseVisualStyleBackColor = True
        Me.chkEpost.Visible = False
        '
        'chkEtternavn
        '
        Me.chkEtternavn.AutoSize = True
        Me.chkEtternavn.Location = New System.Drawing.Point(16, 185)
        Me.chkEtternavn.Name = "chkEtternavn"
        Me.chkEtternavn.Size = New System.Drawing.Size(95, 25)
        Me.chkEtternavn.TabIndex = 12
        Me.chkEtternavn.Text = "Etternavn"
        Me.chkEtternavn.UseVisualStyleBackColor = True
        Me.chkEtternavn.Visible = False
        '
        'chkFornavn
        '
        Me.chkFornavn.AutoSize = True
        Me.chkFornavn.Location = New System.Drawing.Point(16, 139)
        Me.chkFornavn.Name = "chkFornavn"
        Me.chkFornavn.Size = New System.Drawing.Size(86, 25)
        Me.chkFornavn.TabIndex = 11
        Me.chkFornavn.Text = "Fornavn"
        Me.chkFornavn.UseVisualStyleBackColor = True
        Me.chkFornavn.Visible = False
        '
        'txtEpost
        '
        Me.txtEpost.Location = New System.Drawing.Point(144, 235)
        Me.txtEpost.Name = "txtEpost"
        Me.txtEpost.Size = New System.Drawing.Size(116, 29)
        Me.txtEpost.TabIndex = 10
        Me.txtEpost.Visible = False
        '
        'txtEtternavn
        '
        Me.txtEtternavn.Location = New System.Drawing.Point(144, 185)
        Me.txtEtternavn.Name = "txtEtternavn"
        Me.txtEtternavn.Size = New System.Drawing.Size(116, 29)
        Me.txtEtternavn.TabIndex = 9
        Me.txtEtternavn.Visible = False
        '
        'txtFornavn
        '
        Me.txtFornavn.Location = New System.Drawing.Point(144, 139)
        Me.txtFornavn.Name = "txtFornavn"
        Me.txtFornavn.Size = New System.Drawing.Size(116, 29)
        Me.txtFornavn.TabIndex = 8
        Me.txtFornavn.Visible = False
        '
        'txtKID
        '
        Me.txtKID.Location = New System.Drawing.Point(16, 88)
        Me.txtKID.Name = "txtKID"
        Me.txtKID.Size = New System.Drawing.Size(116, 29)
        Me.txtKID.TabIndex = 7
        Me.txtKID.Visible = False
        '
        'lblKID
        '
        Me.lblKID.AutoSize = True
        Me.lblKID.Location = New System.Drawing.Point(138, 91)
        Me.lblKID.Name = "lblKID"
        Me.lblKID.Size = New System.Drawing.Size(217, 21)
        Me.lblKID.TabIndex = 6
        Me.lblKID.Text = "Skriv inn KID på aktuell kunde"
        Me.lblKID.Visible = False
        '
        'btnOppdaterBedKunde
        '
        Me.btnOppdaterBedKunde.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnOppdaterBedKunde.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnOppdaterBedKunde.BeforeTouchSize = New System.Drawing.Size(190, 41)
        Me.btnOppdaterBedKunde.ForeColor = System.Drawing.Color.White
        Me.btnOppdaterBedKunde.IsBackStageButton = False
        Me.btnOppdaterBedKunde.Location = New System.Drawing.Point(280, 16)
        Me.btnOppdaterBedKunde.Name = "btnOppdaterBedKunde"
        Me.btnOppdaterBedKunde.Size = New System.Drawing.Size(190, 41)
        Me.btnOppdaterBedKunde.TabIndex = 5
        Me.btnOppdaterBedKunde.Text = "Oppdater Bedriftskunde"
        Me.btnOppdaterBedKunde.UseVisualStyle = True
        '
        'btnOppdaterPrivKunde
        '
        Me.btnOppdaterPrivKunde.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.btnOppdaterPrivKunde.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.btnOppdaterPrivKunde.BeforeTouchSize = New System.Drawing.Size(206, 42)
        Me.btnOppdaterPrivKunde.ForeColor = System.Drawing.Color.White
        Me.btnOppdaterPrivKunde.IsBackStageButton = False
        Me.btnOppdaterPrivKunde.Location = New System.Drawing.Point(54, 16)
        Me.btnOppdaterPrivKunde.Name = "btnOppdaterPrivKunde"
        Me.btnOppdaterPrivKunde.Size = New System.Drawing.Size(206, 42)
        Me.btnOppdaterPrivKunde.TabIndex = 4
        Me.btnOppdaterPrivKunde.Text = "Oppdater Privatkunde"
        Me.btnOppdaterPrivKunde.UseVisualStyle = True
        '
        'tbKundeEpost
        '
        Me.tbKundeEpost.Controls.Add(Me.Panel6)
        Me.tbKundeEpost.Controls.Add(Me.StatusStripEx1)
        Me.tbKundeEpost.Controls.Add(Me.ToolStripEx11)
        Me.tbKundeEpost.Image = Nothing
        Me.tbKundeEpost.ImageSize = New System.Drawing.Size(16, 16)
        Me.tbKundeEpost.Location = New System.Drawing.Point(38, 3)
        Me.tbKundeEpost.Name = "tbKundeEpost"
        Me.tbKundeEpost.ShowCloseButton = True
        Me.tbKundeEpost.Size = New System.Drawing.Size(823, 387)
        Me.tbKundeEpost.TabIndex = 2
        Me.tbKundeEpost.Text = "Epost"
        Me.tbKundeEpost.ThemesEnabled = True
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel6.Controls.Add(Me.Panel7)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(0, 42)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Padding = New System.Windows.Forms.Padding(50, 10, 50, 0)
        Me.Panel6.Size = New System.Drawing.Size(823, 323)
        Me.Panel6.TabIndex = 3
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.White
        Me.Panel7.Controls.Add(Me.rtbKundeEpost)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(50, 10)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Padding = New System.Windows.Forms.Padding(10, 10, 10, 0)
        Me.Panel7.Size = New System.Drawing.Size(723, 313)
        Me.Panel7.TabIndex = 0
        '
        'rtbKundeEpost
        '
        Me.rtbKundeEpost.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtbKundeEpost.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbKundeEpost.Location = New System.Drawing.Point(10, 10)
        Me.rtbKundeEpost.Name = "rtbKundeEpost"
        Me.rtbKundeEpost.Size = New System.Drawing.Size(703, 303)
        Me.rtbKundeEpost.TabIndex = 0
        Me.rtbKundeEpost.Text = ""
        '
        'StatusStripEx1
        '
        Me.StatusStripEx1.BeforeTouchSize = New System.Drawing.Size(823, 22)
        Me.StatusStripEx1.Dock = Syncfusion.Windows.Forms.Tools.DockStyleEx.Bottom
        Me.StatusStripEx1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStripEx1.Location = New System.Drawing.Point(0, 365)
        Me.StatusStripEx1.MetroColor = System.Drawing.Color.FromArgb(CType(CType(135, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.StatusStripEx1.Name = "StatusStripEx1"
        Me.StatusStripEx1.Size = New System.Drawing.Size(823, 22)
        Me.StatusStripEx1.TabIndex = 2
        Me.StatusStripEx1.Text = "StatusStripEx1"
        Me.StatusStripEx1.VisualStyle = Syncfusion.Windows.Forms.Tools.StatusStripExStyle.Metro
        '
        'ToolStripEx11
        '
        Me.ToolStripEx11.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx11.Image = Nothing
        Me.ToolStripEx11.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx11.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton1, Me.OpenToolStripButton1, Me.SaveToolStripButton1, Me.PrintToolStripButton1, Me.toolStripSeparator5, Me.CutToolStripButton1, Me.CopyToolStripButton1, Me.PasteToolStripButton1, Me.toolStripSeparator6, Me.btnSendEpostKunde, Me.toolstripCMBxKunder, Me.ToolStripLabel1, Me.ToolStripTxtSubject, Me.ToolStripLabel2, Me.ToolStripSplitButtonEx1})
        Me.ToolStripEx11.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx11.Name = "ToolStripEx11"
        Me.ToolStripEx11.Office12Mode = False
        Me.ToolStripEx11.Size = New System.Drawing.Size(823, 42)
        Me.ToolStripEx11.TabIndex = 0
        Me.ToolStripEx11.Text = "Epost"
        Me.ToolStripEx11.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'NewToolStripButton1
        '
        Me.NewToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.txtnewDoc
        Me.NewToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton1.Name = "NewToolStripButton1"
        Me.NewToolStripButton1.Size = New System.Drawing.Size(24, 24)
        Me.NewToolStripButton1.Text = "&New"
        '
        'OpenToolStripButton1
        '
        Me.OpenToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.txtOpen
        Me.OpenToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton1.Name = "OpenToolStripButton1"
        Me.OpenToolStripButton1.Size = New System.Drawing.Size(24, 24)
        Me.OpenToolStripButton1.Text = "&Open"
        '
        'SaveToolStripButton1
        '
        Me.SaveToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.txtSave
        Me.SaveToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton1.Name = "SaveToolStripButton1"
        Me.SaveToolStripButton1.Size = New System.Drawing.Size(24, 24)
        Me.SaveToolStripButton1.Text = "&Save"
        '
        'PrintToolStripButton1
        '
        Me.PrintToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.txtPrint
        Me.PrintToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton1.Name = "PrintToolStripButton1"
        Me.PrintToolStripButton1.Size = New System.Drawing.Size(24, 24)
        Me.PrintToolStripButton1.Text = "&Print"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(6, 27)
        '
        'CutToolStripButton1
        '
        Me.CutToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.txtCut
        Me.CutToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton1.Name = "CutToolStripButton1"
        Me.CutToolStripButton1.Size = New System.Drawing.Size(24, 24)
        Me.CutToolStripButton1.Text = "C&ut"
        '
        'CopyToolStripButton1
        '
        Me.CopyToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.txtCopy
        Me.CopyToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton1.Name = "CopyToolStripButton1"
        Me.CopyToolStripButton1.Size = New System.Drawing.Size(24, 24)
        Me.CopyToolStripButton1.Text = "&Copy"
        '
        'PasteToolStripButton1
        '
        Me.PasteToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.txtPaste
        Me.PasteToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton1.Name = "PasteToolStripButton1"
        Me.PasteToolStripButton1.Size = New System.Drawing.Size(24, 24)
        Me.PasteToolStripButton1.Text = "&Paste"
        '
        'toolStripSeparator6
        '
        Me.toolStripSeparator6.Name = "toolStripSeparator6"
        Me.toolStripSeparator6.Size = New System.Drawing.Size(6, 27)
        '
        'btnSendEpostKunde
        '
        Me.btnSendEpostKunde.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.btnSendEpostKunde.Image = CType(resources.GetObject("btnSendEpostKunde.Image"), System.Drawing.Image)
        Me.btnSendEpostKunde.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSendEpostKunde.Name = "btnSendEpostKunde"
        Me.btnSendEpostKunde.Size = New System.Drawing.Size(89, 24)
        Me.btnSendEpostKunde.Text = "Send Epost"
        '
        'toolstripCMBxKunder
        '
        Me.toolstripCMBxKunder.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.toolstripCMBxKunder.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.toolstripCMBxKunder.MaxLength = 32767
        Me.toolstripCMBxKunder.Name = "toolstripCMBxKunder"
        Me.toolstripCMBxKunder.Size = New System.Drawing.Size(121, 27)
        Me.toolstripCMBxKunder.Style = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(49, 24)
        Me.ToolStripLabel1.Text = "Send til:"
        '
        'ToolStripTxtSubject
        '
        Me.ToolStripTxtSubject.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripTxtSubject.Name = "ToolStripTxtSubject"
        Me.ToolStripTxtSubject.Size = New System.Drawing.Size(200, 27)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(49, 24)
        Me.ToolStripLabel2.Text = "Subject:"
        '
        'ToolStripSplitButtonEx1
        '
        Me.ToolStripSplitButtonEx1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FakturaToolStripMenuItem, Me.NyhetsbrevToolStripMenuItem, Me.VareoversiktToolStripMenuItem})
        Me.ToolStripSplitButtonEx1.Image = CType(resources.GetObject("ToolStripSplitButtonEx1.Image"), System.Drawing.Image)
        Me.ToolStripSplitButtonEx1.Name = "ToolStripSplitButtonEx1"
        Me.ToolStripSplitButtonEx1.Size = New System.Drawing.Size(106, 24)
        Me.ToolStripSplitButtonEx1.Text = "Epost maler"
        '
        'FakturaToolStripMenuItem
        '
        Me.FakturaToolStripMenuItem.Name = "FakturaToolStripMenuItem"
        Me.FakturaToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.FakturaToolStripMenuItem.Text = "Faktura"
        '
        'NyhetsbrevToolStripMenuItem
        '
        Me.NyhetsbrevToolStripMenuItem.Name = "NyhetsbrevToolStripMenuItem"
        Me.NyhetsbrevToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.NyhetsbrevToolStripMenuItem.Text = "Nyhetsbrev"
        '
        'VareoversiktToolStripMenuItem
        '
        Me.VareoversiktToolStripMenuItem.Name = "VareoversiktToolStripMenuItem"
        Me.VareoversiktToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.VareoversiktToolStripMenuItem.Text = "Vareoversikt"
        '
        'ToolStripEx2
        '
        Me.ToolStripEx2.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStripEx2.Image = Nothing
        Me.ToolStripEx2.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton3})
        Me.ToolStripEx2.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx2.Name = "ToolStripEx2"
        Me.ToolStripEx2.Office12Mode = False
        Me.ToolStripEx2.Size = New System.Drawing.Size(872, 42)
        Me.ToolStripEx2.TabIndex = 4
        Me.ToolStripEx2.Text = "Personaliaoversikt"
        Me.ToolStripEx2.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton3.Image = Global.OOPSA.My.Resources.Resources.tbLogout
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(72, 24)
        Me.ToolStripButton3.Text = "Logg ut"
        '
        'tbSalg
        '
        Me.tbSalg.Controls.Add(Me.TabControlAdv2)
        Me.tbSalg.Controls.Add(Me.ToolStripEx3)
        Me.tbSalg.Image = Global.OOPSA.My.Resources.Resources.tbSalg
        Me.tbSalg.ImageSize = New System.Drawing.Size(48, 48)
        Me.tbSalg.Location = New System.Drawing.Point(105, 2)
        Me.tbSalg.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tbSalg.Name = "tbSalg"
        Me.tbSalg.ShowCloseButton = True
        Me.tbSalg.Size = New System.Drawing.Size(872, 475)
        Me.tbSalg.TabIndex = 3
        Me.tbSalg.ThemesEnabled = True
        '
        'TabControlAdv2
        '
        Me.TabControlAdv2.BeforeTouchSize = New System.Drawing.Size(872, 433)
        Me.TabControlAdv2.Controls.Add(Me.tbTextEdit)
        Me.TabControlAdv2.Controls.Add(Me.tbUtleieOversikt)
        Me.TabControlAdv2.Controls.Add(Me.tbReporting)
        Me.TabControlAdv2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlAdv2.ItemSize = New System.Drawing.Size(62, 48)
        Me.TabControlAdv2.Location = New System.Drawing.Point(0, 42)
        Me.TabControlAdv2.Name = "TabControlAdv2"
        Me.TabControlAdv2.Size = New System.Drawing.Size(872, 433)
        Me.TabControlAdv2.TabIndex = 2
        Me.TabControlAdv2.ThemesEnabled = True
        '
        'tbTextEdit
        '
        Me.tbTextEdit.Controls.Add(Me.Panel1)
        Me.tbTextEdit.Controls.Add(Me.ToolStripEx6)
        Me.tbTextEdit.Image = Global.OOPSA.My.Resources.Resources.tbTxtEditor
        Me.tbTextEdit.ImageSize = New System.Drawing.Size(32, 32)
        Me.tbTextEdit.Location = New System.Drawing.Point(3, 53)
        Me.tbTextEdit.Name = "tbTextEdit"
        Me.tbTextEdit.ShowCloseButton = True
        Me.tbTextEdit.Size = New System.Drawing.Size(865, 376)
        Me.tbTextEdit.TabIndex = 2
        Me.tbTextEdit.Text = "Teksteditor"
        Me.tbTextEdit.ThemesEnabled = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 42)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Padding = New System.Windows.Forms.Padding(50, 10, 50, 0)
        Me.Panel1.Size = New System.Drawing.Size(865, 334)
        Me.Panel1.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Panel2.Controls.Add(Me.FontListBox1)
        Me.Panel2.Controls.Add(Me.richTextBox1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(50, 10)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Padding = New System.Windows.Forms.Padding(10)
        Me.Panel2.Size = New System.Drawing.Size(765, 324)
        Me.Panel2.TabIndex = 0
        '
        'FontListBox1
        '
        Me.FontListBox1.FormattingEnabled = True
        Me.FontListBox1.ItemHeight = 15
        Me.FontListBox1.Items.AddRange(New Object() {"! PEPSI !", "Adobe Arabic", "Adobe Caslon Pro", "Adobe Caslon Pro Bold", "Adobe Devanagari", "Adobe Fan Heiti Std B", "Adobe Fangsong Std R", "Adobe Garamond Pro", "Adobe Garamond Pro Bold", "Adobe Gothic Std B", "Adobe Gurmukhi", "Adobe Hebrew", "Adobe Heiti Std R", "Adobe Kaiti Std R", "Adobe Ming Std L", "Adobe Myungjo Std M", "Adobe Naskh Medium", "Adobe Song Std L", "Agency FB", "Algerian", "Andy", "Arial", "Arial Black", "Arial Narrow", "Arial Rounded MT Bold", "Arial Unicode MS", "Atlantic Cruise", "Baskerville Old Face", "Bauhaus 93", "Bell MT", "Berlin Sans FB", "Berlin Sans FB Demi", "Bernard MT Condensed", "Birch Std", "Blackadder ITC", "Blackoak Std", "Bodoni MT", "Bodoni MT Black", "Bodoni MT Condensed", "Bodoni MT Poster Compressed", "Book Antiqua", "Bookman Old Style", "Bookshelf Symbol 7", "Bradley Hand ITC", "Britannic Bold", "Broadway", "Brush Script MT", "Brush Script Std", "Buxton Sketch", "Calibri", "Calibri Light", "Californian FB", "Calisto MT", "Cambria", "Cambria Math", "Candara", "Castellar", "Centaur", "Century", "Century Gothic", "Century Schoolbook", "Chaparral Pro", "Chaparral Pro Light", "Charlemagne Std", "Chiller", "Colonna MT", "Comic Sans MS", "Consolas", "Constantia", "Cooper Black", "Cooper Std Black", "Copperplate Gothic Bold", "Copperplate Gothic Light", "Corbel", "Counter-Strike", "Courier New", "Curlz MT", "DengXian", "DF-GameOver", "Ebrima", "Edwardian Script ITC", "Elephant", "Engravers MT", "Eras Bold ITC", "Eras Demi ITC", "Eras Light ITC", "Eras Medium ITC", "Felix Titling", "Footlight MT Light", "Forte", "Franklin Gothic Book", "Franklin Gothic Demi", "Franklin Gothic Demi Cond", "Franklin Gothic Heavy", "Franklin Gothic Medium", "Franklin Gothic Medium Cond", "Freestyle Script", "French Script MT", "Gabriola", "Gadugi", "Garamond", "Georgia", "Giddyup Std", "Gigi", "Gill Sans MT", "Gill Sans MT Condensed", "Gill Sans MT Ext Condensed Bold", "Gill Sans Ultra Bold", "Gill Sans Ultra Bold Condensed", "Gloucester MT Extra Condensed", "Gotham Thin", "Goudy Old Style", "Goudy Stout", "Haettenschweiler", "Harlow Solid Italic", "Harrington", "High Tower Text", "Hobo Std", "Impact", "Imprint MT Shadow", "Informal Roman", "Javanese Text", "Jing Jing", "Jokerman", "Juice ITC", "Kootenay", "Kozuka Gothic Pr6N B", "Kozuka Gothic Pr6N EL", "Kozuka Gothic Pr6N H", "Kozuka Gothic Pr6N L", "Kozuka Gothic Pr6N M", "Kozuka Gothic Pr6N R", "Kozuka Gothic Pro B", "Kozuka Gothic Pro EL", "Kozuka Gothic Pro H", "Kozuka Gothic Pro L", "Kozuka Gothic Pro M", "Kozuka Gothic Pro R", "Kozuka Mincho Pr6N B", "Kozuka Mincho Pr6N EL", "Kozuka Mincho Pr6N H", "Kozuka Mincho Pr6N L", "Kozuka Mincho Pr6N M", "Kozuka Mincho Pr6N R", "Kozuka Mincho Pro B", "Kozuka Mincho Pro EL", "Kozuka Mincho Pro H", "Kozuka Mincho Pro L", "Kozuka Mincho Pro M", "Kozuka Mincho Pro R", "Kristen ITC", "Kunstler Script", "Leelawadee UI", "Leelawadee UI Semilight", "Letter Gothic Std", "Lindsey", "Lithos Pro Regular", "Lucida Bright", "Lucida Calligraphy", "Lucida Console", "Lucida Fax", "Lucida Handwriting", "Lucida Sans", "Lucida Sans Typewriter", "Lucida Sans Unicode", "Magneto", "Maiandra GD", "Malgun Gothic", "Malgun Gothic Semilight", "Marlett", "Matura MT Script Capitals", "Mesquite Std", "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft JhengHei Light", "Microsoft JhengHei UI", "Microsoft JhengHei UI Light", "Microsoft MHei", "Microsoft NeoGothic", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Sans Serif", "Microsoft Tai Le", "Microsoft YaHei", "Microsoft YaHei Light", "Microsoft YaHei UI", "Microsoft YaHei UI Light", "Microsoft Yi Baiti", "MingLiU-ExtB", "MingLiU_HKSCS-ExtB", "Minion Pro", "Minion Pro Cond", "Minion Pro Med", "Minion Pro SmBd", "Miramonte", "Mistral", "Modern No. 20", "Moire", "Moire ExtraBold", "Moire Light", "Mongolian Baiti", "Monotype Corsiva", "Motorwerk", "MS Gothic", "MS Outlook", "MS PGothic", "MS Reference Sans Serif", "MS Reference Specialty", "MS UI Gothic", "MT Extra", "MV Boli", "Myanmar Text", "Myriad Arabic", "Myriad Hebrew", "Myriad Pro", "Myriad Pro Cond", "Myriad Pro Light", "News Gothic", "Niagara Engraved", "Niagara Solid", "Nirmala UI", "Nirmala UI Semilight", "NSimSun", "Nueva Std", "Nueva Std Cond", "OCR A Extended", "OCR A Std", "Old English Text MT", "Onyx", "Orator Std", "Palace Script MT", "Paladins", "Paladins 3D", "Paladins Condensed", "Paladins Expanded", "Paladins Gradient", "Paladins Laser", "Paladins Leftalic", "Paladins Outline", "Paladins Semi-Italic", "Paladins Straight", "Paladins Super-Italic", "Palatino Linotype", "Papyrus", "Parchment", "Pericles", "Pericles Light", "Perpetua", "Perpetua Titling MT", "Pescadero", "pixelmix", "Playbill", "PMingLiU-ExtB", "Poor Richard", "Poplar Std", "Prestige Elite Std", "Pristina", "Quartz MS", "Rage Italic", "Raleway", "Ravie", "Rockwell", "Rockwell Condensed", "Rockwell Extra Bold", "Rosewood Std Regular", "Script MT Bold", "Segoe Keycaps", "Segoe Marker", "Segoe MDL2 Assets", "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Black", "Segoe UI Emoji", "Segoe UI Historic", "Segoe UI Light", "Segoe UI Mono", "Segoe UI Semibold", "Segoe UI Semilight", "Segoe UI Symbol", "Segoe WP", "Segoe WP Black", "Segoe WP Light", "Segoe WP Semibold", "Segoe WP SemiLight", "Showcard Gothic", "SimSun", "SimSun-ExtB", "Sitka Banner", "Sitka Display", "Sitka Heading", "Sitka Small", "Sitka Subheading", "Sitka Text", "SketchFlow Print", "Snap ITC", "Source Code Pro", "Source Code Pro Black", "Source Code Pro ExtraLight", "Source Code Pro Light", "Source Code Pro Semibold", "Source Sans Pro", "Source Sans Pro Black", "Source Sans Pro ExtraLight", "Source Sans Pro Light", "Source Sans Pro Semibold", "Stencil", "Stencil Std", "Sylfaen", "Symbol", "Tahoma", "Tekton Pro", "Tekton Pro Cond", "Tekton Pro Ext", "Tempus Sans ITC", "Times New Roman", "Trajan Pro", "Trajan Pro 3", "Transatlantic Cruise Demo", "Trebuchet MS", "Tw Cen MT", "Tw Cen MT Condensed", "Tw Cen MT Condensed Extra Bold", "Verdana", "Viner Hand ITC", "Vivaldi", "Vladimir Script", "Wasco Sans", "Webdings", "Wide Latin", "Wingdings", "Wingdings 2", "Wingdings 3", "Yu Gothic", "Yu Gothic Light", "Yu Gothic Medium", "Yu Gothic UI", "Yu Gothic UI Light", "Yu Gothic UI Semibold", "Yu Gothic UI Semilight", "ZWAdobeF"})
        Me.FontListBox1.Location = New System.Drawing.Point(124, -7)
        Me.FontListBox1.MetroColor = System.Drawing.SystemColors.Highlight
        Me.FontListBox1.Name = "FontListBox1"
        MetroColorTable1.ArrowChecked = System.Drawing.Color.FromArgb(CType(CType(147, Byte), Integer), CType(CType(149, Byte), Integer), CType(CType(152, Byte), Integer))
        MetroColorTable1.ArrowInActive = System.Drawing.Color.White
        MetroColorTable1.ArrowNormal = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer))
        MetroColorTable1.ArrowNormalBackGround = System.Drawing.Color.Empty
        MetroColorTable1.ArrowPushed = System.Drawing.Color.FromArgb(CType(CType(88, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(90, Byte), Integer))
        MetroColorTable1.ArrowPushedBackGround = System.Drawing.Color.Empty
        MetroColorTable1.ScrollerBackground = System.Drawing.Color.White
        MetroColorTable1.ThumbChecked = System.Drawing.Color.FromArgb(CType(CType(147, Byte), Integer), CType(CType(149, Byte), Integer), CType(CType(152, Byte), Integer))
        MetroColorTable1.ThumbInActive = System.Drawing.Color.White
        MetroColorTable1.ThumbNormal = System.Drawing.Color.FromArgb(CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer), CType(CType(198, Byte), Integer))
        MetroColorTable1.ThumbPushed = System.Drawing.Color.FromArgb(CType(CType(88, Byte), Integer), CType(CType(89, Byte), Integer), CType(CType(90, Byte), Integer))
        MetroColorTable1.ThumbPushedBorder = System.Drawing.Color.Empty
        Me.FontListBox1.ScrollMetroColorTable = MetroColorTable1
        Me.FontListBox1.Size = New System.Drawing.Size(138, 244)
        Me.FontListBox1.TabIndex = 4
        Me.FontListBox1.Visible = False
        '
        'richTextBox1
        '
        Me.richTextBox1.BackColor = System.Drawing.Color.White
        Me.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.richTextBox1.EnableAutoDragDrop = True
        Me.richTextBox1.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.richTextBox1.Location = New System.Drawing.Point(10, 10)
        Me.richTextBox1.Margin = New System.Windows.Forms.Padding(50)
        Me.richTextBox1.Name = "richTextBox1"
        Me.richTextBox1.Size = New System.Drawing.Size(745, 304)
        Me.richTextBox1.TabIndex = 2
        Me.richTextBox1.Text = ""
        '
        'ToolStripEx6
        '
        Me.ToolStripEx6.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx6.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStripEx6.Image = Nothing
        Me.ToolStripEx6.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx6.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton, Me.OpenToolStripButton, Me.SaveToolStripButton, Me.PrintToolStripButton, Me.toolStripSeparator, Me.CutToolStripButton, Me.CopyToolStripButton, Me.PasteToolStripButton, Me.toolStripSeparator1, Me.txtUndo, Me.txtRedo, Me.ToolStripSeparator4, Me.txtFontCombo, Me.txtFontSizeCombo, Me.ToolStripSeparator2, Me.txtInsertImg, Me.ToolStripButton4, Me.ToolStripSeparator3, Me.txtAlignLeft, Me.txtAlignJust, Me.txtAlignRight})
        Me.ToolStripEx6.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx6.Name = "ToolStripEx6"
        Me.ToolStripEx6.Office12Mode = False
        Me.ToolStripEx6.Size = New System.Drawing.Size(865, 42)
        Me.ToolStripEx6.TabIndex = 2
        Me.ToolStripEx6.Text = "Teksteditor"
        Me.ToolStripEx6.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'NewToolStripButton
        '
        Me.NewToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton.Image = Global.OOPSA.My.Resources.Resources.txtnewDoc
        Me.NewToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NewToolStripButton.Name = "NewToolStripButton"
        Me.NewToolStripButton.Size = New System.Drawing.Size(24, 24)
        Me.NewToolStripButton.Text = "&New"
        '
        'OpenToolStripButton
        '
        Me.OpenToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton.Image = Global.OOPSA.My.Resources.Resources.txtOpen
        Me.OpenToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.OpenToolStripButton.Name = "OpenToolStripButton"
        Me.OpenToolStripButton.Size = New System.Drawing.Size(24, 24)
        Me.OpenToolStripButton.Text = "&Open"
        '
        'SaveToolStripButton
        '
        Me.SaveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton.Image = Global.OOPSA.My.Resources.Resources.txtSave
        Me.SaveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SaveToolStripButton.Name = "SaveToolStripButton"
        Me.SaveToolStripButton.Size = New System.Drawing.Size(24, 24)
        Me.SaveToolStripButton.Text = "&Save"
        '
        'PrintToolStripButton
        '
        Me.PrintToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton.Image = Global.OOPSA.My.Resources.Resources.txtPrint
        Me.PrintToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PrintToolStripButton.Name = "PrintToolStripButton"
        Me.PrintToolStripButton.Size = New System.Drawing.Size(24, 24)
        Me.PrintToolStripButton.Text = "&Print"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(6, 27)
        '
        'CutToolStripButton
        '
        Me.CutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CutToolStripButton.Image = Global.OOPSA.My.Resources.Resources.txtCut
        Me.CutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripButton.Name = "CutToolStripButton"
        Me.CutToolStripButton.Size = New System.Drawing.Size(24, 24)
        Me.CutToolStripButton.Text = "C&ut"
        '
        'CopyToolStripButton
        '
        Me.CopyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CopyToolStripButton.Image = Global.OOPSA.My.Resources.Resources.txtCopy
        Me.CopyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripButton.Name = "CopyToolStripButton"
        Me.CopyToolStripButton.Size = New System.Drawing.Size(24, 24)
        Me.CopyToolStripButton.Text = "&Copy"
        '
        'PasteToolStripButton
        '
        Me.PasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PasteToolStripButton.Image = Global.OOPSA.My.Resources.Resources.txtPaste
        Me.PasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripButton.Name = "PasteToolStripButton"
        Me.PasteToolStripButton.Size = New System.Drawing.Size(24, 24)
        Me.PasteToolStripButton.Text = "&Paste"
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'txtUndo
        '
        Me.txtUndo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.txtUndo.Image = Global.OOPSA.My.Resources.Resources.txtUndo
        Me.txtUndo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.txtUndo.Name = "txtUndo"
        Me.txtUndo.Size = New System.Drawing.Size(24, 24)
        Me.txtUndo.Text = "ToolStripButton2"
        '
        'txtRedo
        '
        Me.txtRedo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.txtRedo.Image = Global.OOPSA.My.Resources.Resources.txtRedo
        Me.txtRedo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.txtRedo.Name = "txtRedo"
        Me.txtRedo.Size = New System.Drawing.Size(24, 24)
        Me.txtRedo.Text = "ToolStripButton3"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 27)
        '
        'txtFontCombo
        '
        Me.txtFontCombo.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtFontCombo.Margin = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.txtFontCombo.MaxLength = 32767
        Me.txtFontCombo.Name = "txtFontCombo"
        Me.txtFontCombo.Size = New System.Drawing.Size(135, 27)
        Me.txtFontCombo.Style = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        Me.txtFontCombo.Text = "Arial"
        '
        'txtFontSizeCombo
        '
        Me.txtFontSizeCombo.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtFontSizeCombo.Items.AddRange(New Object() {"8", "9", "10", "11", "12", "14", "16", "18", "20", "22", "24", "26", "28", "36", "48", "72"})
        Me.txtFontSizeCombo.MaxLength = 32767
        Me.txtFontSizeCombo.Name = "txtFontSizeCombo"
        Me.txtFontSizeCombo.Size = New System.Drawing.Size(45, 27)
        Me.txtFontSizeCombo.Style = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        Me.txtFontSizeCombo.Text = "8"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'txtInsertImg
        '
        Me.txtInsertImg.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.txtInsertImg.Image = Global.OOPSA.My.Resources.Resources.txtInsert
        Me.txtInsertImg.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.txtInsertImg.Name = "txtInsertImg"
        Me.txtInsertImg.Size = New System.Drawing.Size(24, 24)
        Me.txtInsertImg.Text = "txtInsert"
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(23, 24)
        Me.ToolStripButton4.Text = "ToolStripButton4"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 27)
        '
        'txtAlignLeft
        '
        Me.txtAlignLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.txtAlignLeft.Image = Global.OOPSA.My.Resources.Resources.txtAlignLeft
        Me.txtAlignLeft.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.txtAlignLeft.Name = "txtAlignLeft"
        Me.txtAlignLeft.Size = New System.Drawing.Size(24, 24)
        Me.txtAlignLeft.Text = "ToolStripButton5"
        '
        'txtAlignJust
        '
        Me.txtAlignJust.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.txtAlignJust.Image = Global.OOPSA.My.Resources.Resources.txtAlignJust
        Me.txtAlignJust.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.txtAlignJust.Name = "txtAlignJust"
        Me.txtAlignJust.Size = New System.Drawing.Size(24, 24)
        Me.txtAlignJust.Text = "ToolStripButton6"
        '
        'txtAlignRight
        '
        Me.txtAlignRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.txtAlignRight.Image = Global.OOPSA.My.Resources.Resources.txtAlignRight
        Me.txtAlignRight.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.txtAlignRight.Name = "txtAlignRight"
        Me.txtAlignRight.Size = New System.Drawing.Size(24, 24)
        Me.txtAlignRight.Text = "ToolStripButton7"
        '
        'tbUtleieOversikt
        '
        Me.tbUtleieOversikt.Controls.Add(Me.ButtonLeggTilLeie)
        Me.tbUtleieOversikt.Controls.Add(Me.GridDataBoundGrid1)
        Me.tbUtleieOversikt.Image = Global.OOPSA.My.Resources.Resources.tbRent
        Me.tbUtleieOversikt.ImageSize = New System.Drawing.Size(32, 32)
        Me.tbUtleieOversikt.Location = New System.Drawing.Point(3, 53)
        Me.tbUtleieOversikt.Name = "tbUtleieOversikt"
        Me.tbUtleieOversikt.ShowCloseButton = True
        Me.tbUtleieOversikt.Size = New System.Drawing.Size(865, 376)
        Me.tbUtleieOversikt.TabIndex = 4
        Me.tbUtleieOversikt.Text = "Utleie"
        Me.tbUtleieOversikt.ThemesEnabled = True
        '
        'ButtonLeggTilLeie
        '
        Me.ButtonLeggTilLeie.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.ButtonLeggTilLeie.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.ButtonLeggTilLeie.BeforeTouchSize = New System.Drawing.Size(186, 60)
        Me.ButtonLeggTilLeie.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonLeggTilLeie.ForeColor = System.Drawing.Color.White
        Me.ButtonLeggTilLeie.IsBackStageButton = False
        Me.ButtonLeggTilLeie.Location = New System.Drawing.Point(0, 0)
        Me.ButtonLeggTilLeie.Name = "ButtonLeggTilLeie"
        Me.ButtonLeggTilLeie.Size = New System.Drawing.Size(186, 60)
        Me.ButtonLeggTilLeie.TabIndex = 3
        Me.ButtonLeggTilLeie.Text = "Legg til leie"
        Me.ButtonLeggTilLeie.UseVisualStyle = True
        '
        'GridDataBoundGrid1
        '
        Me.GridDataBoundGrid1.AllowDragSelectedCols = True
        Me.GridDataBoundGrid1.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle13.Name = "Column Header"
        GridBaseStyle13.StyleInfo.BaseStyle = "Header"
        GridBaseStyle13.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle13.StyleInfo.Enabled = False
        GridBaseStyle13.StyleInfo.Font.Bold = True
        GridBaseStyle13.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle14.Name = "Header"
        GridBaseStyle14.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle14.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle14.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle14.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle14.StyleInfo.CellType = "Header"
        GridBaseStyle14.StyleInfo.Font.Bold = True
        GridBaseStyle14.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle14.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle15.Name = "Standard"
        GridBaseStyle15.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle15.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle15.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle16.Name = "Row Header"
        GridBaseStyle16.StyleInfo.BaseStyle = "Header"
        GridBaseStyle16.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle16.StyleInfo.Enabled = True
        GridBaseStyle16.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.GridDataBoundGrid1.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle13, GridBaseStyle14, GridBaseStyle15, GridBaseStyle16})
        Me.GridDataBoundGrid1.DefaultRowHeight = 20
        Me.GridDataBoundGrid1.Dock = System.Windows.Forms.DockStyle.Right
        Me.GridDataBoundGrid1.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.GridDataBoundGrid1.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.GridDataBoundGrid1.Location = New System.Drawing.Point(186, 0)
        Me.GridDataBoundGrid1.MetroScrollBars = True
        Me.GridDataBoundGrid1.Name = "GridDataBoundGrid1"
        Me.GridDataBoundGrid1.OptimizeInsertRemoveCells = True
        Me.GridDataBoundGrid1.Properties.ForceImmediateRepaint = False
        Me.GridDataBoundGrid1.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.GridDataBoundGrid1.Properties.MarkColHeader = False
        Me.GridDataBoundGrid1.Properties.MarkRowHeader = False
        Me.GridDataBoundGrid1.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.GridDataBoundGrid1.Size = New System.Drawing.Size(679, 376)
        Me.GridDataBoundGrid1.SmartSizeBox = False
        Me.GridDataBoundGrid1.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.GridDataBoundGrid1.TabIndex = 2
        Me.GridDataBoundGrid1.Text = "GridDataBoundGrid1"
        Me.GridDataBoundGrid1.ThemesEnabled = True
        Me.GridDataBoundGrid1.UseListChangedEvent = True
        Me.GridDataBoundGrid1.UseRightToLeftCompatibleTextBox = True
        '
        'tbReporting
        '
        Me.tbReporting.Controls.Add(Me.ReportViewer4)
        Me.tbReporting.Image = Global.OOPSA.My.Resources.Resources.tbReport
        Me.tbReporting.ImageSize = New System.Drawing.Size(32, 32)
        Me.tbReporting.Location = New System.Drawing.Point(3, 53)
        Me.tbReporting.Name = "tbReporting"
        Me.tbReporting.ShowCloseButton = True
        Me.tbReporting.Size = New System.Drawing.Size(865, 376)
        Me.tbReporting.TabIndex = 3
        Me.tbReporting.Text = "Rapporter"
        Me.tbReporting.ThemesEnabled = True
        '
        'ReportViewer4
        '
        Me.ReportViewer4.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource4.Name = "dsSalgsRapport"
        ReportDataSource4.Value = Me.SalgsRaportBindingSource
        Me.ReportViewer4.LocalReport.DataSources.Add(ReportDataSource4)
        Me.ReportViewer4.LocalReport.ReportEmbeddedResource = "OOPSA.SalgsRapport.rdlc"
        Me.ReportViewer4.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer4.Name = "ReportViewer4"
        Me.ReportViewer4.Size = New System.Drawing.Size(865, 376)
        Me.ReportViewer4.TabIndex = 1
        '
        'ToolStripEx3
        '
        Me.ToolStripEx3.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStripEx3.Image = Nothing
        Me.ToolStripEx3.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton5})
        Me.ToolStripEx3.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx3.Name = "ToolStripEx3"
        Me.ToolStripEx3.Office12Mode = False
        Me.ToolStripEx3.Size = New System.Drawing.Size(872, 42)
        Me.ToolStripEx3.TabIndex = 1
        Me.ToolStripEx3.Text = "Salg & Utleie"
        Me.ToolStripEx3.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton5.Image = Global.OOPSA.My.Resources.Resources.tbLogout
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(72, 24)
        Me.ToolStripButton5.Text = "Logg ut"
        '
        'tbSettings
        '
        Me.tbSettings.Controls.Add(Me.Panel3)
        Me.tbSettings.Controls.Add(Me.ToolStripEx5)
        Me.tbSettings.Image = Global.OOPSA.My.Resources.Resources.tbSettings
        Me.tbSettings.ImageSize = New System.Drawing.Size(48, 48)
        Me.tbSettings.Location = New System.Drawing.Point(105, 2)
        Me.tbSettings.Name = "tbSettings"
        Me.tbSettings.ShowCloseButton = True
        Me.tbSettings.Size = New System.Drawing.Size(872, 475)
        Me.tbSettings.TabIndex = 5
        Me.tbSettings.ThemesEnabled = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.tabSettings)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 42)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(872, 433)
        Me.Panel3.TabIndex = 2
        '
        'tabSettings
        '
        Me.tabSettings.ActiveTabColor = System.Drawing.Color.Transparent
        Me.tabSettings.BeforeTouchSize = New System.Drawing.Size(872, 433)
        Me.tabSettings.Controls.Add(Me.TabPageAdv1)
        Me.tabSettings.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabSettings.InactiveTabColor = System.Drawing.Color.Transparent
        Me.tabSettings.Location = New System.Drawing.Point(0, 0)
        Me.tabSettings.Name = "tabSettings"
        Me.tabSettings.Size = New System.Drawing.Size(872, 433)
        Me.tabSettings.TabIndex = 0
        Me.tabSettings.TabPanelBackColor = System.Drawing.Color.Transparent
        Me.tabSettings.ThemesEnabled = True
        '
        'TabPageAdv1
        '
        Me.TabPageAdv1.Controls.Add(Me.SplitContainer1)
        Me.TabPageAdv1.Image = Nothing
        Me.TabPageAdv1.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv1.Location = New System.Drawing.Point(3, 2)
        Me.TabPageAdv1.Name = "TabPageAdv1"
        Me.TabPageAdv1.ShowCloseButton = True
        Me.TabPageAdv1.Size = New System.Drawing.Size(865, 427)
        Me.TabPageAdv1.TabIndex = 1
        Me.TabPageAdv1.Text = "Database"
        Me.TabPageAdv1.ThemesEnabled = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.dgvSQLQuery)
        Me.SplitContainer1.Size = New System.Drawing.Size(865, 427)
        Me.SplitContainer1.SplitterDistance = 288
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtSvrPassRep)
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtSvrPass)
        Me.SplitContainer2.Panel1.Controls.Add(Me.TxtSvrUser)
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtSvrDB)
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtServer)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblSvrPassRep)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblSvrPass)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblSvrUser)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblDB)
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblServer)
        Me.SplitContainer2.Panel1.Controls.Add(Me.toolstripDBInfo)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Panel4)
        Me.SplitContainer2.Panel2.Controls.Add(Me.ToolStripEx10)
        Me.SplitContainer2.Size = New System.Drawing.Size(288, 427)
        Me.SplitContainer2.SplitterDistance = 229
        Me.SplitContainer2.TabIndex = 0
        '
        'txtSvrPassRep
        '
        Me.txtSvrPassRep.BeforeTouchSize = New System.Drawing.Size(116, 23)
        Me.txtSvrPassRep.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSvrPassRep.Location = New System.Drawing.Point(104, 184)
        Me.txtSvrPassRep.Metrocolor = System.Drawing.Color.FromArgb(CType(CType(209, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(212, Byte), Integer))
        Me.txtSvrPassRep.Name = "txtSvrPassRep"
        Me.txtSvrPassRep.Size = New System.Drawing.Size(181, 29)
        Me.txtSvrPassRep.Style = Syncfusion.Windows.Forms.Tools.TextBoxExt.theme.[Default]
        Me.txtSvrPassRep.TabIndex = 9
        Me.txtSvrPassRep.Text = "TextBoxExt5"
        '
        'txtSvrPass
        '
        Me.txtSvrPass.BeforeTouchSize = New System.Drawing.Size(116, 23)
        Me.txtSvrPass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSvrPass.Location = New System.Drawing.Point(104, 149)
        Me.txtSvrPass.Metrocolor = System.Drawing.Color.FromArgb(CType(CType(209, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(212, Byte), Integer))
        Me.txtSvrPass.Name = "txtSvrPass"
        Me.txtSvrPass.Size = New System.Drawing.Size(181, 29)
        Me.txtSvrPass.Style = Syncfusion.Windows.Forms.Tools.TextBoxExt.theme.[Default]
        Me.txtSvrPass.TabIndex = 8
        Me.txtSvrPass.Text = "TextBoxExt4"
        '
        'TxtSvrUser
        '
        Me.TxtSvrUser.BeforeTouchSize = New System.Drawing.Size(116, 23)
        Me.TxtSvrUser.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TxtSvrUser.Location = New System.Drawing.Point(104, 114)
        Me.TxtSvrUser.Metrocolor = System.Drawing.Color.FromArgb(CType(CType(209, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(212, Byte), Integer))
        Me.TxtSvrUser.Name = "TxtSvrUser"
        Me.TxtSvrUser.Size = New System.Drawing.Size(181, 29)
        Me.TxtSvrUser.Style = Syncfusion.Windows.Forms.Tools.TextBoxExt.theme.[Default]
        Me.TxtSvrUser.TabIndex = 7
        Me.TxtSvrUser.Text = "TextBoxExt3"
        '
        'txtSvrDB
        '
        Me.txtSvrDB.BeforeTouchSize = New System.Drawing.Size(116, 23)
        Me.txtSvrDB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtSvrDB.Location = New System.Drawing.Point(104, 79)
        Me.txtSvrDB.Metrocolor = System.Drawing.Color.FromArgb(CType(CType(209, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(212, Byte), Integer))
        Me.txtSvrDB.Name = "txtSvrDB"
        Me.txtSvrDB.Size = New System.Drawing.Size(181, 29)
        Me.txtSvrDB.Style = Syncfusion.Windows.Forms.Tools.TextBoxExt.theme.[Default]
        Me.txtSvrDB.TabIndex = 6
        Me.txtSvrDB.Text = "TextBoxExt2"
        '
        'txtServer
        '
        Me.txtServer.BeforeTouchSize = New System.Drawing.Size(116, 23)
        Me.txtServer.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtServer.Location = New System.Drawing.Point(104, 43)
        Me.txtServer.Metrocolor = System.Drawing.Color.FromArgb(CType(CType(209, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(212, Byte), Integer))
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(181, 29)
        Me.txtServer.Style = Syncfusion.Windows.Forms.Tools.TextBoxExt.theme.[Default]
        Me.txtServer.TabIndex = 0
        Me.txtServer.Text = "TextBoxExt1"
        '
        'lblSvrPassRep
        '
        Me.lblSvrPassRep.Location = New System.Drawing.Point(3, 187)
        Me.lblSvrPassRep.Name = "lblSvrPassRep"
        Me.lblSvrPassRep.Size = New System.Drawing.Size(95, 21)
        Me.lblSvrPassRep.TabIndex = 5
        Me.lblSvrPassRep.Text = "Repeat Pass:"
        '
        'lblSvrPass
        '
        Me.lblSvrPass.Location = New System.Drawing.Point(3, 152)
        Me.lblSvrPass.Name = "lblSvrPass"
        Me.lblSvrPass.Size = New System.Drawing.Size(79, 21)
        Me.lblSvrPass.TabIndex = 4
        Me.lblSvrPass.Text = "Password:"
        '
        'lblSvrUser
        '
        Me.lblSvrUser.Location = New System.Drawing.Point(3, 117)
        Me.lblSvrUser.Name = "lblSvrUser"
        Me.lblSvrUser.Size = New System.Drawing.Size(84, 21)
        Me.lblSvrUser.TabIndex = 3
        Me.lblSvrUser.Text = "Username:"
        '
        'lblDB
        '
        Me.lblDB.Location = New System.Drawing.Point(3, 82)
        Me.lblDB.Name = "lblDB"
        Me.lblDB.Size = New System.Drawing.Size(77, 21)
        Me.lblDB.TabIndex = 2
        Me.lblDB.Text = "Database:"
        '
        'lblServer
        '
        Me.lblServer.Location = New System.Drawing.Point(3, 46)
        Me.lblServer.Name = "lblServer"
        Me.lblServer.Size = New System.Drawing.Size(58, 21)
        Me.lblServer.TabIndex = 1
        Me.lblServer.Text = "Server:"
        '
        'toolstripDBInfo
        '
        Me.toolstripDBInfo.ForeColor = System.Drawing.Color.MidnightBlue
        Me.toolstripDBInfo.Image = Nothing
        Me.toolstripDBInfo.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.toolstripDBInfo.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsBtnDBInfo})
        Me.toolstripDBInfo.Location = New System.Drawing.Point(0, 0)
        Me.toolstripDBInfo.Name = "toolstripDBInfo"
        Me.toolstripDBInfo.Office12Mode = False
        Me.toolstripDBInfo.Size = New System.Drawing.Size(288, 42)
        Me.toolstripDBInfo.TabIndex = 0
        Me.toolstripDBInfo.Text = "Database Information"
        Me.toolstripDBInfo.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'tsBtnDBInfo
        '
        Me.tsBtnDBInfo.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.tsBtnDBInfo.Image = Global.OOPSA.My.Resources.Resources.icoDatabase
        Me.tsBtnDBInfo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsBtnDBInfo.Name = "tsBtnDBInfo"
        Me.tsBtnDBInfo.Size = New System.Drawing.Size(189, 24)
        Me.tsBtnDBInfo.Text = "Change Database Information"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.rtbSQLQuery)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 42)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(288, 152)
        Me.Panel4.TabIndex = 2
        '
        'rtbSQLQuery
        '
        Me.rtbSQLQuery.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rtbSQLQuery.Dock = System.Windows.Forms.DockStyle.Fill
        Me.rtbSQLQuery.Location = New System.Drawing.Point(0, 0)
        Me.rtbSQLQuery.Name = "rtbSQLQuery"
        Me.rtbSQLQuery.Size = New System.Drawing.Size(288, 152)
        Me.rtbSQLQuery.TabIndex = 0
        Me.rtbSQLQuery.Text = "SELECT {column_name}" & Global.Microsoft.VisualBasic.ChrW(10) & "FROM {table_name}" & Global.Microsoft.VisualBasic.ChrW(10) & "WHERE {condition}"
        '
        'ToolStripEx10
        '
        Me.ToolStripEx10.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx10.Image = Nothing
        Me.ToolStripEx10.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx10.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripLabel3})
        Me.ToolStripEx10.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx10.Name = "ToolStripEx10"
        Me.ToolStripEx10.Office12Mode = False
        Me.ToolStripEx10.Size = New System.Drawing.Size(288, 42)
        Me.ToolStripEx10.TabIndex = 1
        Me.ToolStripEx10.Text = "SQL Query Builder"
        Me.ToolStripEx10.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.Image = Global.OOPSA.My.Resources.Resources.icoDatabase
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(71, 24)
        Me.ToolStripButton1.Text = "Execute"
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(88, 24)
        Me.ToolStripLabel3.Text = "ToolStripLabel3"
        '
        'dgvSQLQuery
        '
        Me.dgvSQLQuery.AllowDragSelectedCols = True
        Me.dgvSQLQuery.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle17.Name = "Column Header"
        GridBaseStyle17.StyleInfo.BaseStyle = "Header"
        GridBaseStyle17.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle17.StyleInfo.Enabled = False
        GridBaseStyle17.StyleInfo.Font.Bold = True
        GridBaseStyle17.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle18.Name = "Header"
        GridBaseStyle18.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle18.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle18.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle18.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle18.StyleInfo.CellType = "Header"
        GridBaseStyle18.StyleInfo.Font.Bold = True
        GridBaseStyle18.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle18.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle19.Name = "Standard"
        GridBaseStyle19.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle19.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle19.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle20.Name = "Row Header"
        GridBaseStyle20.StyleInfo.BaseStyle = "Header"
        GridBaseStyle20.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle20.StyleInfo.Enabled = True
        GridBaseStyle20.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.dgvSQLQuery.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle17, GridBaseStyle18, GridBaseStyle19, GridBaseStyle20})
        Me.dgvSQLQuery.DefaultColWidth = 100
        Me.dgvSQLQuery.DefaultRowHeight = 20
        Me.dgvSQLQuery.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvSQLQuery.EnableAddNew = False
        Me.dgvSQLQuery.EnableEdit = False
        Me.dgvSQLQuery.EnableRemove = False
        Me.dgvSQLQuery.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.dgvSQLQuery.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.dgvSQLQuery.Location = New System.Drawing.Point(0, 0)
        Me.dgvSQLQuery.MetroScrollBars = True
        Me.dgvSQLQuery.Name = "dgvSQLQuery"
        Me.dgvSQLQuery.OptimizeInsertRemoveCells = True
        Me.dgvSQLQuery.Properties.ForceImmediateRepaint = False
        Me.dgvSQLQuery.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.dgvSQLQuery.Properties.MarkColHeader = False
        Me.dgvSQLQuery.Properties.MarkRowHeader = False
        Me.dgvSQLQuery.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.dgvSQLQuery.Size = New System.Drawing.Size(573, 427)
        Me.dgvSQLQuery.SmartSizeBox = False
        Me.dgvSQLQuery.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.dgvSQLQuery.TabIndex = 0
        Me.dgvSQLQuery.Text = "GridDataBoundGrid7"
        Me.dgvSQLQuery.ThemesEnabled = True
        Me.dgvSQLQuery.UseListChangedEvent = True
        Me.dgvSQLQuery.UseRightToLeftCompatibleTextBox = True
        '
        'ToolStripEx5
        '
        Me.ToolStripEx5.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx5.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStripEx5.Image = Nothing
        Me.ToolStripEx5.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx5.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton6})
        Me.ToolStripEx5.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx5.Name = "ToolStripEx5"
        Me.ToolStripEx5.Office12Mode = False
        Me.ToolStripEx5.Size = New System.Drawing.Size(872, 42)
        Me.ToolStripEx5.TabIndex = 1
        Me.ToolStripEx5.Text = "Oversikt"
        Me.ToolStripEx5.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton6.Image = Global.OOPSA.My.Resources.Resources.tbLogout
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(72, 24)
        Me.ToolStripButton6.Text = "Logg ut"
        '
        'tbLager
        '
        Me.tbLager.Controls.Add(Me.TabLager)
        Me.tbLager.Controls.Add(Me.ToolStripEx4)
        Me.tbLager.Image = Global.OOPSA.My.Resources.Resources.tbLager
        Me.tbLager.ImageSize = New System.Drawing.Size(48, 48)
        Me.tbLager.Location = New System.Drawing.Point(105, 2)
        Me.tbLager.Name = "tbLager"
        Me.tbLager.ShowCloseButton = True
        Me.tbLager.Size = New System.Drawing.Size(872, 475)
        Me.tbLager.TabIndex = 4
        Me.tbLager.ThemesEnabled = True
        '
        'TabLager
        '
        Me.TabLager.BeforeTouchSize = New System.Drawing.Size(872, 433)
        Me.TabLager.Controls.Add(Me.TabPageAdv5)
        Me.TabLager.Controls.Add(Me.TabPageAdv6)
        Me.TabLager.Controls.Add(Me.TabPageAdv7)
        Me.TabLager.Controls.Add(Me.TabPageAdv2)
        Me.TabLager.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabLager.Location = New System.Drawing.Point(0, 42)
        Me.TabLager.Name = "TabLager"
        Me.TabLager.Size = New System.Drawing.Size(872, 433)
        Me.TabLager.TabIndex = 2
        Me.TabLager.ThemesEnabled = True
        '
        'TabPageAdv5
        '
        Me.TabPageAdv5.Controls.Add(Me.GridDataBoundGrid4)
        Me.TabPageAdv5.Image = Nothing
        Me.TabPageAdv5.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv5.Location = New System.Drawing.Point(3, 35)
        Me.TabPageAdv5.Name = "TabPageAdv5"
        Me.TabPageAdv5.ShowCloseButton = True
        Me.TabPageAdv5.Size = New System.Drawing.Size(865, 394)
        Me.TabPageAdv5.TabIndex = 1
        Me.TabPageAdv5.Text = "Alle Lager"
        Me.TabPageAdv5.ThemesEnabled = True
        '
        'GridDataBoundGrid4
        '
        Me.GridDataBoundGrid4.AllowDragSelectedCols = True
        Me.GridDataBoundGrid4.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle21.Name = "Column Header"
        GridBaseStyle21.StyleInfo.BaseStyle = "Header"
        GridBaseStyle21.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle21.StyleInfo.Enabled = False
        GridBaseStyle21.StyleInfo.Font.Bold = True
        GridBaseStyle21.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle22.Name = "Header"
        GridBaseStyle22.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle22.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle22.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle22.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle22.StyleInfo.CellType = "Header"
        GridBaseStyle22.StyleInfo.Font.Bold = True
        GridBaseStyle22.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle22.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle23.Name = "Standard"
        GridBaseStyle23.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle23.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle23.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle24.Name = "Row Header"
        GridBaseStyle24.StyleInfo.BaseStyle = "Header"
        GridBaseStyle24.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle24.StyleInfo.Enabled = True
        GridBaseStyle24.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.GridDataBoundGrid4.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle21, GridBaseStyle22, GridBaseStyle23, GridBaseStyle24})
        Me.GridDataBoundGrid4.DataSource = Me.LagerRapportALLEBindingSource
        Me.GridDataBoundGrid4.DefaultRowHeight = 20
        Me.GridDataBoundGrid4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridDataBoundGrid4.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.GridDataBoundGrid4.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.GridDataBoundGrid4.Location = New System.Drawing.Point(0, 0)
        Me.GridDataBoundGrid4.MetroScrollBars = True
        Me.GridDataBoundGrid4.Name = "GridDataBoundGrid4"
        Me.GridDataBoundGrid4.OptimizeInsertRemoveCells = True
        Me.GridDataBoundGrid4.Properties.ForceImmediateRepaint = False
        Me.GridDataBoundGrid4.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.GridDataBoundGrid4.Properties.MarkColHeader = False
        Me.GridDataBoundGrid4.Properties.MarkRowHeader = False
        Me.GridDataBoundGrid4.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.GridDataBoundGrid4.Size = New System.Drawing.Size(865, 394)
        Me.GridDataBoundGrid4.SmartSizeBox = False
        Me.GridDataBoundGrid4.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.GridDataBoundGrid4.TabIndex = 0
        Me.GridDataBoundGrid4.Text = "GridDataBoundGrid4"
        Me.GridDataBoundGrid4.ThemesEnabled = True
        Me.GridDataBoundGrid4.UseListChangedEvent = True
        Me.GridDataBoundGrid4.UseRightToLeftCompatibleTextBox = True
        '
        'TabPageAdv6
        '
        Me.TabPageAdv6.Controls.Add(Me.GridDataBoundGrid3)
        Me.TabPageAdv6.Image = Nothing
        Me.TabPageAdv6.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv6.Location = New System.Drawing.Point(3, 35)
        Me.TabPageAdv6.Name = "TabPageAdv6"
        Me.TabPageAdv6.ShowCloseButton = True
        Me.TabPageAdv6.Size = New System.Drawing.Size(865, 394)
        Me.TabPageAdv6.TabIndex = 2
        Me.TabPageAdv6.Text = "Trondheim" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.TabPageAdv6.ThemesEnabled = True
        '
        'GridDataBoundGrid3
        '
        Me.GridDataBoundGrid3.AllowDragSelectedCols = True
        Me.GridDataBoundGrid3.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle25.Name = "Column Header"
        GridBaseStyle25.StyleInfo.BaseStyle = "Header"
        GridBaseStyle25.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle25.StyleInfo.Enabled = False
        GridBaseStyle25.StyleInfo.Font.Bold = True
        GridBaseStyle25.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle26.Name = "Header"
        GridBaseStyle26.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle26.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle26.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle26.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle26.StyleInfo.CellType = "Header"
        GridBaseStyle26.StyleInfo.Font.Bold = True
        GridBaseStyle26.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle26.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle27.Name = "Standard"
        GridBaseStyle27.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle27.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle27.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle28.Name = "Row Header"
        GridBaseStyle28.StyleInfo.BaseStyle = "Header"
        GridBaseStyle28.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle28.StyleInfo.Enabled = True
        GridBaseStyle28.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.GridDataBoundGrid3.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle25, GridBaseStyle26, GridBaseStyle27, GridBaseStyle28})
        Me.GridDataBoundGrid3.DataSource = Me.LagerRapportTrondheimBindingSource
        Me.GridDataBoundGrid3.DefaultRowHeight = 20
        Me.GridDataBoundGrid3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridDataBoundGrid3.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.GridDataBoundGrid3.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.GridDataBoundGrid3.Location = New System.Drawing.Point(0, 0)
        Me.GridDataBoundGrid3.MetroScrollBars = True
        Me.GridDataBoundGrid3.Name = "GridDataBoundGrid3"
        Me.GridDataBoundGrid3.OptimizeInsertRemoveCells = True
        Me.GridDataBoundGrid3.Properties.ForceImmediateRepaint = False
        Me.GridDataBoundGrid3.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.GridDataBoundGrid3.Properties.MarkColHeader = False
        Me.GridDataBoundGrid3.Properties.MarkRowHeader = False
        Me.GridDataBoundGrid3.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.GridDataBoundGrid3.Size = New System.Drawing.Size(865, 394)
        Me.GridDataBoundGrid3.SmartSizeBox = False
        Me.GridDataBoundGrid3.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.GridDataBoundGrid3.TabIndex = 0
        Me.GridDataBoundGrid3.Text = "GridDataBoundGrid3"
        Me.GridDataBoundGrid3.ThemesEnabled = True
        Me.GridDataBoundGrid3.UseListChangedEvent = True
        Me.GridDataBoundGrid3.UseRightToLeftCompatibleTextBox = True
        '
        'LagerRapportTrondheimBindingSource
        '
        Me.LagerRapportTrondheimBindingSource.DataMember = "LagerRapportTrondheim"
        Me.LagerRapportTrondheimBindingSource.DataSource = Me.Drift8_2016DataSetTrondheimLager
        '
        'Drift8_2016DataSetTrondheimLager
        '
        Me.Drift8_2016DataSetTrondheimLager.DataSetName = "drift8_2016DataSetTrondheimLager"
        Me.Drift8_2016DataSetTrondheimLager.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TabPageAdv7
        '
        Me.TabPageAdv7.Controls.Add(Me.GridDataBoundGrid2)
        Me.TabPageAdv7.Image = Nothing
        Me.TabPageAdv7.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv7.Location = New System.Drawing.Point(3, 35)
        Me.TabPageAdv7.Name = "TabPageAdv7"
        Me.TabPageAdv7.ShowCloseButton = True
        Me.TabPageAdv7.Size = New System.Drawing.Size(865, 394)
        Me.TabPageAdv7.TabIndex = 3
        Me.TabPageAdv7.Text = "Stavanger"
        Me.TabPageAdv7.ThemesEnabled = True
        '
        'GridDataBoundGrid2
        '
        Me.GridDataBoundGrid2.AllowDragSelectedCols = True
        Me.GridDataBoundGrid2.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle29.Name = "Column Header"
        GridBaseStyle29.StyleInfo.BaseStyle = "Header"
        GridBaseStyle29.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle29.StyleInfo.Enabled = False
        GridBaseStyle29.StyleInfo.Font.Bold = True
        GridBaseStyle29.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle30.Name = "Header"
        GridBaseStyle30.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle30.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle30.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle30.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle30.StyleInfo.CellType = "Header"
        GridBaseStyle30.StyleInfo.Font.Bold = True
        GridBaseStyle30.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle30.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle31.Name = "Standard"
        GridBaseStyle31.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle31.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle31.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle32.Name = "Row Header"
        GridBaseStyle32.StyleInfo.BaseStyle = "Header"
        GridBaseStyle32.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle32.StyleInfo.Enabled = True
        GridBaseStyle32.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.GridDataBoundGrid2.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle29, GridBaseStyle30, GridBaseStyle31, GridBaseStyle32})
        Me.GridDataBoundGrid2.DataSource = Me.LagerRapportStavangerBindingSource
        Me.GridDataBoundGrid2.DefaultRowHeight = 20
        Me.GridDataBoundGrid2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridDataBoundGrid2.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.GridDataBoundGrid2.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.GridDataBoundGrid2.Location = New System.Drawing.Point(0, 0)
        Me.GridDataBoundGrid2.MetroScrollBars = True
        Me.GridDataBoundGrid2.Name = "GridDataBoundGrid2"
        Me.GridDataBoundGrid2.OptimizeInsertRemoveCells = True
        Me.GridDataBoundGrid2.Properties.ForceImmediateRepaint = False
        Me.GridDataBoundGrid2.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.GridDataBoundGrid2.Properties.MarkColHeader = False
        Me.GridDataBoundGrid2.Properties.MarkRowHeader = False
        Me.GridDataBoundGrid2.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.GridDataBoundGrid2.Size = New System.Drawing.Size(865, 394)
        Me.GridDataBoundGrid2.SmartSizeBox = False
        Me.GridDataBoundGrid2.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.GridDataBoundGrid2.TabIndex = 0
        Me.GridDataBoundGrid2.Text = "GridDataBoundGrid2"
        Me.GridDataBoundGrid2.ThemesEnabled = True
        Me.GridDataBoundGrid2.UseListChangedEvent = True
        Me.GridDataBoundGrid2.UseRightToLeftCompatibleTextBox = True
        '
        'LagerRapportStavangerBindingSource
        '
        Me.LagerRapportStavangerBindingSource.DataMember = "LagerRapportStavanger"
        Me.LagerRapportStavangerBindingSource.DataSource = Me.Drift8_2016DataSetLagerRapportStavnager
        '
        'Drift8_2016DataSetLagerRapportStavnager
        '
        Me.Drift8_2016DataSetLagerRapportStavnager.DataSetName = "drift8_2016DataSetLagerRapportStavnager"
        Me.Drift8_2016DataSetLagerRapportStavnager.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TabPageAdv2
        '
        Me.TabPageAdv2.Controls.Add(Me.ReportViewer5)
        Me.TabPageAdv2.Image = Nothing
        Me.TabPageAdv2.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv2.Location = New System.Drawing.Point(3, 35)
        Me.TabPageAdv2.Name = "TabPageAdv2"
        Me.TabPageAdv2.ShowCloseButton = True
        Me.TabPageAdv2.Size = New System.Drawing.Size(865, 394)
        Me.TabPageAdv2.TabIndex = 4
        Me.TabPageAdv2.Text = "Rapport"
        Me.TabPageAdv2.ThemesEnabled = True
        '
        'ReportViewer5
        '
        Me.ReportViewer5.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource5.Name = "LagerRapport"
        ReportDataSource5.Value = Me.LagerRapportALLEBindingSource
        Me.ReportViewer5.LocalReport.DataSources.Add(ReportDataSource5)
        Me.ReportViewer5.LocalReport.ReportEmbeddedResource = "OOPSA.LagerRapport.rdlc"
        Me.ReportViewer5.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer5.Name = "ReportViewer5"
        Me.ReportViewer5.Size = New System.Drawing.Size(865, 394)
        Me.ReportViewer5.TabIndex = 1
        '
        'ToolStripEx4
        '
        Me.ToolStripEx4.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripEx4.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStripEx4.Image = Nothing
        Me.ToolStripEx4.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStripEx4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton7})
        Me.ToolStripEx4.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripEx4.Name = "ToolStripEx4"
        Me.ToolStripEx4.Office12Mode = False
        Me.ToolStripEx4.Size = New System.Drawing.Size(872, 42)
        Me.ToolStripEx4.TabIndex = 1
        Me.ToolStripEx4.Text = "Lageroversikt"
        Me.ToolStripEx4.VisualStyle = Syncfusion.Windows.Forms.Tools.ToolStripExStyle.Metro
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton7.Image = Global.OOPSA.My.Resources.Resources.tbLogout
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(72, 24)
        Me.ToolStripButton7.Text = "Logg ut"
        '
        'Drift82016DataSetBindingSource
        '
        Me.Drift82016DataSetBindingSource.DataSource = Me.drift8_2016DataSet
        Me.Drift82016DataSetBindingSource.Position = 0
        '
        'KundeBindingSource
        '
        Me.KundeBindingSource.DataMember = "Kunde"
        Me.KundeBindingSource.DataSource = Me.drift8_2016DataSet
        '
        'StatusStripLabel1
        '
        Me.StatusStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.StatusStripLabel1.Margin = New System.Windows.Forms.Padding(0, 4, 0, 2)
        Me.StatusStripLabel1.Name = "StatusStripLabel1"
        Me.StatusStripLabel1.Size = New System.Drawing.Size(87, 15)
        Me.StatusStripLabel1.Text = "Email Progress:"
        '
        'StatusStripProgressBar1
        '
        Me.StatusStripProgressBar1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.StatusStripProgressBar1.Margin = New System.Windows.Forms.Padding(0, 4, 0, 2)
        Me.StatusStripProgressBar1.Name = "StatusStripProgressBar1"
        Me.StatusStripProgressBar1.Size = New System.Drawing.Size(100, 15)
        Me.StatusStripProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        '
        'StatusStripLabel2
        '
        Me.StatusStripLabel2.Margin = New System.Windows.Forms.Padding(0, 4, 0, 2)
        Me.StatusStripLabel2.Name = "StatusStripLabel2"
        Me.StatusStripLabel2.Size = New System.Drawing.Size(97, 15)
        Me.StatusStripLabel2.Text = "StatusStripLabel2"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'KjøpTableAdapter
        '
        Me.KjøpTableAdapter.ClearBeforeFill = True
        '
        'AnsattTableAdapter
        '
        Me.AnsattTableAdapter.ClearBeforeFill = True
        '
        'SpellChecker1
        '
        Me.SpellChecker1.CustomDictionaryPath = "C:\ProgramData\Microsoft Corporation\Microsoft® Visual Studio® 2015\14.0.24720.0\" &
    "Custom_Dictionay.dic"
        Me.SpellChecker1.DictionaryPath = "Syncfusion_en_us.dic"
        Me.SpellChecker1.MetroColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.SpellChecker1.VisualStyle = Syncfusion.Text.SpellCheckerStyle.[Default]
        '
        'SalgsRaportTableAdapter
        '
        Me.SalgsRaportTableAdapter.ClearBeforeFill = True
        '
        'Drift82016dsSalgsRapportViewBindingSource
        '
        Me.Drift82016dsSalgsRapportViewBindingSource.DataSource = Me.drift8_2016dsSalgsRapportView
        Me.Drift82016dsSalgsRapportViewBindingSource.Position = 0
        '
        'SalgsRaportBindingSource1
        '
        Me.SalgsRaportBindingSource1.DataMember = "SalgsRaport"
        Me.SalgsRaportBindingSource1.DataSource = Me.Drift82016dsSalgsRapportViewBindingSource
        '
        'KundeTableAdapter
        '
        Me.KundeTableAdapter.ClearBeforeFill = True
        '
        'A_LagerTableAdapter1
        '
        Me.A_LagerTableAdapter1.ClearBeforeFill = True
        '
        'SalgsRaportBindingSource3
        '
        Me.SalgsRaportBindingSource3.DataMember = "SalgsRaport"
        Me.SalgsRaportBindingSource3.DataSource = Me.drift8_2016dsSalgsRapportView
        '
        'LagerRapportTrondheimTableAdapter
        '
        Me.LagerRapportTrondheimTableAdapter.ClearBeforeFill = True
        '
        'LagerRapportALLETableAdapter
        '
        Me.LagerRapportALLETableAdapter.ClearBeforeFill = True
        '
        'LagerRapportStavangerTableAdapter
        '
        Me.LagerRapportStavangerTableAdapter.ClearBeforeFill = True
        '
        'TabPageAdv9
        '
        Me.TabPageAdv9.Controls.Add(Me.SplitContainerAdv2)
        Me.TabPageAdv9.Image = Nothing
        Me.TabPageAdv9.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv9.Location = New System.Drawing.Point(1, 0)
        Me.TabPageAdv9.Name = "TabPageAdv9"
        Me.TabPageAdv9.ShowCloseButton = True
        Me.TabPageAdv9.Size = New System.Drawing.Size(197, 98)
        Me.TabPageAdv9.TabIndex = 1
        Me.TabPageAdv9.Text = "Ansatte"
        Me.TabPageAdv9.ThemesEnabled = False
        '
        'SplitContainerAdv2
        '
        Me.SplitContainerAdv2.BeforeTouchSize = 7
        Me.SplitContainerAdv2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainerAdv2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainerAdv2.Name = "SplitContainerAdv2"
        '
        'SplitContainerAdv2.Panel1
        '
        Me.SplitContainerAdv2.Panel1.Controls.Add(Me.ButtonAdv1)
        Me.SplitContainerAdv2.Panel1.Controls.Add(Me.ButtonAdv2)
        Me.SplitContainerAdv2.Panel1.Controls.Add(Me.ButtonAdv3)
        '
        'SplitContainerAdv2.Panel2
        '
        Me.SplitContainerAdv2.Panel2.Controls.Add(Me.TabControlAdv8)
        Me.SplitContainerAdv2.Size = New System.Drawing.Size(197, 98)
        Me.SplitContainerAdv2.SplitterDistance = 39
        Me.SplitContainerAdv2.TabIndex = 4
        Me.SplitContainerAdv2.Text = "SplitContainerAdv1"
        '
        'ButtonAdv1
        '
        Me.ButtonAdv1.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.ButtonAdv1.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.ButtonAdv1.BeforeTouchSize = New System.Drawing.Size(39, 60)
        Me.ButtonAdv1.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonAdv1.ForeColor = System.Drawing.Color.White
        Me.ButtonAdv1.IsBackStageButton = False
        Me.ButtonAdv1.Location = New System.Drawing.Point(0, 120)
        Me.ButtonAdv1.Name = "ButtonAdv1"
        Me.ButtonAdv1.Size = New System.Drawing.Size(39, 60)
        Me.ButtonAdv1.TabIndex = 4
        Me.ButtonAdv1.Text = "Oppdater Ansatte"
        Me.ButtonAdv1.UseVisualStyle = True
        '
        'ButtonAdv2
        '
        Me.ButtonAdv2.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.ButtonAdv2.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.ButtonAdv2.BeforeTouchSize = New System.Drawing.Size(39, 60)
        Me.ButtonAdv2.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonAdv2.ForeColor = System.Drawing.Color.White
        Me.ButtonAdv2.IsBackStageButton = False
        Me.ButtonAdv2.Location = New System.Drawing.Point(0, 60)
        Me.ButtonAdv2.Name = "ButtonAdv2"
        Me.ButtonAdv2.Size = New System.Drawing.Size(39, 60)
        Me.ButtonAdv2.TabIndex = 3
        Me.ButtonAdv2.Text = "Endre passord " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for ansatt"
        Me.ButtonAdv2.UseVisualStyle = True
        '
        'ButtonAdv3
        '
        Me.ButtonAdv3.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.ButtonAdv3.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.ButtonAdv3.BeforeTouchSize = New System.Drawing.Size(39, 60)
        Me.ButtonAdv3.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonAdv3.ForeColor = System.Drawing.Color.White
        Me.ButtonAdv3.IsBackStageButton = False
        Me.ButtonAdv3.Location = New System.Drawing.Point(0, 0)
        Me.ButtonAdv3.Name = "ButtonAdv3"
        Me.ButtonAdv3.Size = New System.Drawing.Size(39, 60)
        Me.ButtonAdv3.TabIndex = 2
        Me.ButtonAdv3.Text = "Legg til ansatt"
        Me.ButtonAdv3.UseVisualStyle = True
        '
        'TabControlAdv8
        '
        Me.TabControlAdv8.BeforeTouchSize = New System.Drawing.Size(151, 98)
        Me.TabControlAdv8.Controls.Add(Me.TabPageAdv10)
        Me.TabControlAdv8.Controls.Add(Me.TabPageAdv11)
        Me.TabControlAdv8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControlAdv8.Location = New System.Drawing.Point(0, 0)
        Me.TabControlAdv8.Name = "TabControlAdv8"
        Me.TabControlAdv8.Size = New System.Drawing.Size(151, 98)
        Me.TabControlAdv8.TabIndex = 2
        Me.TabControlAdv8.ThemesEnabled = True
        '
        'TabPageAdv10
        '
        Me.TabPageAdv10.Controls.Add(Me.GridDataBoundGrid5)
        Me.TabPageAdv10.Image = Nothing
        Me.TabPageAdv10.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv10.Location = New System.Drawing.Point(3, 27)
        Me.TabPageAdv10.Name = "TabPageAdv10"
        Me.TabPageAdv10.ShowCloseButton = True
        Me.TabPageAdv10.Size = New System.Drawing.Size(144, 67)
        Me.TabPageAdv10.TabIndex = 1
        Me.TabPageAdv10.Text = "TabPageAdv4"
        Me.TabPageAdv10.ThemesEnabled = True
        '
        'GridDataBoundGrid5
        '
        Me.GridDataBoundGrid5.AllowDragSelectedCols = True
        Me.GridDataBoundGrid5.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle33.Name = "Column Header"
        GridBaseStyle33.StyleInfo.BaseStyle = "Header"
        GridBaseStyle33.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle33.StyleInfo.Enabled = False
        GridBaseStyle33.StyleInfo.Font.Bold = True
        GridBaseStyle33.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle34.Name = "Header"
        GridBaseStyle34.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle34.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle34.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle34.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle34.StyleInfo.CellType = "Header"
        GridBaseStyle34.StyleInfo.Font.Bold = True
        GridBaseStyle34.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle34.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle35.Name = "Standard"
        GridBaseStyle35.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle35.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle35.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle36.Name = "Row Header"
        GridBaseStyle36.StyleInfo.BaseStyle = "Header"
        GridBaseStyle36.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle36.StyleInfo.Enabled = True
        GridBaseStyle36.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.GridDataBoundGrid5.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle33, GridBaseStyle34, GridBaseStyle35, GridBaseStyle36})
        Me.GridDataBoundGrid5.DataMember = ""
        Me.GridDataBoundGrid5.DataSource = Me.AnsattBindingSource
        Me.GridDataBoundGrid5.DefaultRowHeight = 20
        Me.GridDataBoundGrid5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridDataBoundGrid5.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.GridDataBoundGrid5.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.GridDataBoundGrid5.Location = New System.Drawing.Point(0, 0)
        Me.GridDataBoundGrid5.MetroScrollBars = True
        Me.GridDataBoundGrid5.Name = "GridDataBoundGrid5"
        Me.GridDataBoundGrid5.OptimizeInsertRemoveCells = True
        Me.GridDataBoundGrid5.Properties.ForceImmediateRepaint = False
        Me.GridDataBoundGrid5.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.GridDataBoundGrid5.Properties.MarkColHeader = False
        Me.GridDataBoundGrid5.Properties.MarkRowHeader = False
        Me.GridDataBoundGrid5.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.GridDataBoundGrid5.Size = New System.Drawing.Size(144, 67)
        Me.GridDataBoundGrid5.SmartSizeBox = False
        Me.GridDataBoundGrid5.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.GridDataBoundGrid5.TabIndex = 1
        Me.GridDataBoundGrid5.Text = "GridDataBoundGrid1"
        Me.GridDataBoundGrid5.ThemesEnabled = True
        Me.GridDataBoundGrid5.UseListChangedEvent = True
        Me.GridDataBoundGrid5.UseRightToLeftCompatibleTextBox = True
        '
        'TabPageAdv11
        '
        Me.TabPageAdv11.Image = Nothing
        Me.TabPageAdv11.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv11.Location = New System.Drawing.Point(3, 27)
        Me.TabPageAdv11.Name = "TabPageAdv11"
        Me.TabPageAdv11.ShowCloseButton = True
        Me.TabPageAdv11.Size = New System.Drawing.Size(144, 67)
        Me.TabPageAdv11.TabIndex = 2
        Me.TabPageAdv11.Text = "TabPageAdv8"
        Me.TabPageAdv11.ThemesEnabled = True
        '
        'TabPageAdv12
        '
        Me.TabPageAdv12.Image = Nothing
        Me.TabPageAdv12.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv12.Location = New System.Drawing.Point(0, 0)
        Me.TabPageAdv12.Name = "TabPageAdv12"
        Me.TabPageAdv12.ShowCloseButton = True
        Me.TabPageAdv12.Size = New System.Drawing.Size(200, 100)
        Me.TabPageAdv12.TabFont = Nothing
        Me.TabPageAdv12.TabIndex = 0
        Me.TabPageAdv12.ThemesEnabled = False
        '
        'TabControlAdv9
        '
        Me.TabControlAdv9.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.TabControlAdv9.BeforeTouchSize = New System.Drawing.Size(200, 100)
        Me.TabControlAdv9.Controls.Add(Me.TabPageAdv13)
        Me.TabControlAdv9.Location = New System.Drawing.Point(0, 0)
        Me.TabControlAdv9.Name = "TabControlAdv9"
        Me.TabControlAdv9.Size = New System.Drawing.Size(200, 100)
        Me.TabControlAdv9.TabIndex = 0
        '
        'TabPageAdv13
        '
        Me.TabPageAdv13.Controls.Add(Me.SplitContainer4)
        Me.TabPageAdv13.Image = Nothing
        Me.TabPageAdv13.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv13.Location = New System.Drawing.Point(0, 1)
        Me.TabPageAdv13.Name = "TabPageAdv13"
        Me.TabPageAdv13.ShowCloseButton = True
        Me.TabPageAdv13.Size = New System.Drawing.Size(198, 97)
        Me.TabPageAdv13.TabIndex = 1
        Me.TabPageAdv13.Text = "Kunder"
        Me.TabPageAdv13.ThemesEnabled = False
        '
        'SplitContainer4
        '
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.Controls.Add(Me.ButtonAdv4)
        Me.SplitContainer4.Panel1.Controls.Add(Me.ButtonAdv5)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.GridDataBoundGrid6)
        Me.SplitContainer4.Size = New System.Drawing.Size(198, 97)
        Me.SplitContainer4.SplitterDistance = 65
        Me.SplitContainer4.TabIndex = 0
        '
        'ButtonAdv4
        '
        Me.ButtonAdv4.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.ButtonAdv4.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.ButtonAdv4.BeforeTouchSize = New System.Drawing.Size(65, 60)
        Me.ButtonAdv4.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonAdv4.ForeColor = System.Drawing.Color.White
        Me.ButtonAdv4.IsBackStageButton = False
        Me.ButtonAdv4.Location = New System.Drawing.Point(0, 60)
        Me.ButtonAdv4.Name = "ButtonAdv4"
        Me.ButtonAdv4.Size = New System.Drawing.Size(65, 60)
        Me.ButtonAdv4.TabIndex = 4
        Me.ButtonAdv4.Text = "Oppdater Kunde"
        Me.ButtonAdv4.UseVisualStyle = True
        '
        'ButtonAdv5
        '
        Me.ButtonAdv5.Appearance = Syncfusion.Windows.Forms.ButtonAppearance.Metro
        Me.ButtonAdv5.BackColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(165, Byte), Integer), CType(CType(220, Byte), Integer))
        Me.ButtonAdv5.BeforeTouchSize = New System.Drawing.Size(65, 60)
        Me.ButtonAdv5.Dock = System.Windows.Forms.DockStyle.Top
        Me.ButtonAdv5.ForeColor = System.Drawing.Color.White
        Me.ButtonAdv5.IsBackStageButton = False
        Me.ButtonAdv5.Location = New System.Drawing.Point(0, 0)
        Me.ButtonAdv5.Name = "ButtonAdv5"
        Me.ButtonAdv5.Size = New System.Drawing.Size(65, 60)
        Me.ButtonAdv5.TabIndex = 3
        Me.ButtonAdv5.Text = "Legg til ny kunde"
        Me.ButtonAdv5.UseVisualStyle = True
        '
        'GridDataBoundGrid6
        '
        Me.GridDataBoundGrid6.AllowDragSelectedCols = True
        Me.GridDataBoundGrid6.AlphaBlendSelectionColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(171, Byte), Integer), CType(CType(222, Byte), Integer))
        GridBaseStyle37.Name = "Column Header"
        GridBaseStyle37.StyleInfo.BaseStyle = "Header"
        GridBaseStyle37.StyleInfo.CellType = "ColumnHeaderCell"
        GridBaseStyle37.StyleInfo.Enabled = False
        GridBaseStyle37.StyleInfo.Font.Bold = True
        GridBaseStyle37.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Center
        GridBaseStyle38.Name = "Header"
        GridBaseStyle38.StyleInfo.Borders.Bottom = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle38.StyleInfo.Borders.Left = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle38.StyleInfo.Borders.Right = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle38.StyleInfo.Borders.Top = New Syncfusion.Windows.Forms.Grid.GridBorder(Syncfusion.Windows.Forms.Grid.GridBorderStyle.None)
        GridBaseStyle38.StyleInfo.CellType = "Header"
        GridBaseStyle38.StyleInfo.Font.Bold = True
        GridBaseStyle38.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Control)
        GridBaseStyle38.StyleInfo.VerticalAlignment = Syncfusion.Windows.Forms.Grid.GridVerticalAlignment.Middle
        GridBaseStyle39.Name = "Standard"
        GridBaseStyle39.StyleInfo.CheckBoxOptions.CheckedValue = "True"
        GridBaseStyle39.StyleInfo.CheckBoxOptions.UncheckedValue = "False"
        GridBaseStyle39.StyleInfo.Interior = New Syncfusion.Drawing.BrushInfo(System.Drawing.SystemColors.Window)
        GridBaseStyle40.Name = "Row Header"
        GridBaseStyle40.StyleInfo.BaseStyle = "Header"
        GridBaseStyle40.StyleInfo.CellType = "RowHeaderCell"
        GridBaseStyle40.StyleInfo.Enabled = True
        GridBaseStyle40.StyleInfo.HorizontalAlignment = Syncfusion.Windows.Forms.Grid.GridHorizontalAlignment.Left
        Me.GridDataBoundGrid6.BaseStylesMap.AddRange(New Syncfusion.Windows.Forms.Grid.GridBaseStyle() {GridBaseStyle37, GridBaseStyle38, GridBaseStyle39, GridBaseStyle40})
        Me.GridDataBoundGrid6.DataSource = Me.KundeBindingSource
        Me.GridDataBoundGrid6.DefaultRowHeight = 20
        Me.GridDataBoundGrid6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GridDataBoundGrid6.GridOfficeScrollBars = Syncfusion.Windows.Forms.OfficeScrollBars.Metro
        Me.GridDataBoundGrid6.GridVisualStyles = Syncfusion.Windows.Forms.GridVisualStyles.Metro
        Me.GridDataBoundGrid6.Location = New System.Drawing.Point(0, 0)
        Me.GridDataBoundGrid6.MetroScrollBars = True
        Me.GridDataBoundGrid6.Name = "GridDataBoundGrid6"
        Me.GridDataBoundGrid6.OptimizeInsertRemoveCells = True
        Me.GridDataBoundGrid6.Properties.ForceImmediateRepaint = False
        Me.GridDataBoundGrid6.Properties.GridLineColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(234, Byte), Integer))
        Me.GridDataBoundGrid6.Properties.MarkColHeader = False
        Me.GridDataBoundGrid6.Properties.MarkRowHeader = False
        Me.GridDataBoundGrid6.ShowCurrentCellBorderBehavior = Syncfusion.Windows.Forms.Grid.GridShowCurrentCellBorder.GrayWhenLostFocus
        Me.GridDataBoundGrid6.Size = New System.Drawing.Size(129, 97)
        Me.GridDataBoundGrid6.SmartSizeBox = False
        Me.GridDataBoundGrid6.SortBehavior = Syncfusion.Windows.Forms.Grid.GridSortBehavior.DoubleClick
        Me.GridDataBoundGrid6.TabIndex = 0
        Me.GridDataBoundGrid6.Text = "GridDataBoundGrid2"
        Me.GridDataBoundGrid6.ThemesEnabled = True
        Me.GridDataBoundGrid6.UseListChangedEvent = True
        Me.GridDataBoundGrid6.UseRightToLeftCompatibleTextBox = True
        '
        'TabPageAdv14
        '
        Me.TabPageAdv14.Controls.Add(Me.Panel10)
        Me.TabPageAdv14.Controls.Add(Me.StatusStripEx2)
        Me.TabPageAdv14.Image = Nothing
        Me.TabPageAdv14.ImageSize = New System.Drawing.Size(16, 16)
        Me.TabPageAdv14.Location = New System.Drawing.Point(0, 0)
        Me.TabPageAdv14.Name = "TabPageAdv14"
        Me.TabPageAdv14.ShowCloseButton = True
        Me.TabPageAdv14.Size = New System.Drawing.Size(200, 100)
        Me.TabPageAdv14.TabFont = Nothing
        Me.TabPageAdv14.TabIndex = 0
        Me.TabPageAdv14.ThemesEnabled = False
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel10.Controls.Add(Me.Panel11)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel10.Location = New System.Drawing.Point(0, 0)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Padding = New System.Windows.Forms.Padding(50, 10, 50, 0)
        Me.Panel10.Size = New System.Drawing.Size(200, 78)
        Me.Panel10.TabIndex = 3
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.White
        Me.Panel11.Controls.Add(Me.RichTextBox2)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel11.Location = New System.Drawing.Point(50, 10)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Padding = New System.Windows.Forms.Padding(10, 10, 10, 0)
        Me.Panel11.Size = New System.Drawing.Size(100, 68)
        Me.Panel11.TabIndex = 0
        '
        'RichTextBox2
        '
        Me.RichTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox2.Location = New System.Drawing.Point(10, 10)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(80, 58)
        Me.RichTextBox2.TabIndex = 0
        Me.RichTextBox2.Text = ""
        '
        'StatusStripEx2
        '
        Me.StatusStripEx2.BackColor = System.Drawing.Color.FromArgb(CType(CType(135, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.StatusStripEx2.BeforeTouchSize = New System.Drawing.Size(200, 22)
        Me.StatusStripEx2.Dock = Syncfusion.Windows.Forms.Tools.DockStyleEx.Bottom
        Me.StatusStripEx2.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStripEx2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StatusStripLabel1, Me.StatusStripProgressBar1, Me.StatusStripLabel2})
        Me.StatusStripEx2.Location = New System.Drawing.Point(0, 78)
        Me.StatusStripEx2.MetroColor = System.Drawing.Color.FromArgb(CType(CType(135, Byte), Integer), CType(CType(206, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.StatusStripEx2.Name = "StatusStripEx2"
        Me.StatusStripEx2.Size = New System.Drawing.Size(200, 22)
        Me.StatusStripEx2.TabIndex = 2
        Me.StatusStripEx2.Text = "StatusStripEx1"
        Me.StatusStripEx2.VisualStyle = Syncfusion.Windows.Forms.Tools.StatusStripExStyle.Metro
        '
        'TabControlAdv7
        '
        Me.TabControlAdv7.BeforeTouchSize = New System.Drawing.Size(200, 100)
        Me.TabControlAdv7.Controls.Add(Me.TabPageAdv9)
        Me.TabControlAdv7.Location = New System.Drawing.Point(0, 0)
        Me.TabControlAdv7.Name = "TabControlAdv7"
        Me.TabControlAdv7.Size = New System.Drawing.Size(200, 100)
        Me.TabControlAdv7.TabIndex = 0
        '
        'VisAnsattesSalgBindingSource
        '
        Me.VisAnsattesSalgBindingSource.DataMember = "VisAnsattesSalg"
        '
        'VisAktiveLeieTableAdapter
        '
        Me.VisAktiveLeieTableAdapter.ClearBeforeFill = True
        '
        'frmAdminMetro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.CaptionBarColor = System.Drawing.Color.FromArgb(CType(CType(17, Byte), Integer), CType(CType(158, Byte), Integer), CType(CType(218, Byte), Integer))
        Me.CaptionBarHeight = 48
        CaptionImage1.BackColor = System.Drawing.Color.Transparent
        CaptionImage1.Image = Global.OOPSA.My.Resources.Resources.DagligLeder
        CaptionImage1.Name = "capDagligLeder"
        CaptionImage1.Size = New System.Drawing.Size(48, 48)
        Me.CaptionImages.Add(CaptionImage1)
        Me.ClientSize = New System.Drawing.Size(979, 479)
        Me.Controls.Add(Me.tbAnsKund)
        Me.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(6, 7, 6, 7)
        Me.Name = "frmAdminMetro"
        Me.ShowIcon = False
        Me.Text = "Daglig Leder | OOPSA - BADR08"
        CType(Me.SalgsRaportBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.drift8_2016dsSalgsRapportView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LagerRapportALLEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Drift8_2016DataSetLageroversiktALLE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VisAktiveLeieBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.drift8_2016dsVisLeieRapportView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VisLeieBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SalgsRaportBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KjøpBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.drift8_2016DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbAnsKund, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbAnsKund.ResumeLayout(False)
        Me.tbOverview.ResumeLayout(False)
        Me.tbOverview.PerformLayout()
        CType(Me.TabControlAdv3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv3.ResumeLayout(False)
        Me.TabPageAdv3.ResumeLayout(False)
        CType(Me.TabControlAdv4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv4.ResumeLayout(False)
        Me.reportSalg.ResumeLayout(False)
        Me.reportSalg.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.reportLager.ResumeLayout(False)
        Me.reportLager.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.reportLeie.ResumeLayout(False)
        Me.reportLeie.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.ToolStripEx1.ResumeLayout(False)
        Me.ToolStripEx1.PerformLayout()
        Me.tbPersoner.ResumeLayout(False)
        Me.tbPersoner.PerformLayout()
        CType(Me.GradientPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GradientPanel1.ResumeLayout(False)
        CType(Me.TabControlAdv5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv5.ResumeLayout(False)
        Me.tbAnsatte.ResumeLayout(False)
        Me.SplitContainerAdv1.Panel1.ResumeLayout(False)
        Me.SplitContainerAdv1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainerAdv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainerAdv1.ResumeLayout(False)
        CType(Me.TabControlAdv6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv6.ResumeLayout(False)
        Me.TabPageAdv4.ResumeLayout(False)
        CType(Me.dgvAnsatte, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AnsattBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbKunder.ResumeLayout(False)
        CType(Me.TabControlAdv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv1.ResumeLayout(False)
        Me.tbKunderOversikt.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.tbKundeOversikt, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbKundeOversikt.ResumeLayout(False)
        Me.TabPageAdv15.ResumeLayout(False)
        CType(Me.dgvPrivatKunde, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageAdv16.ResumeLayout(False)
        CType(Me.dgvBedriftKunde, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TbOppdaterKunde.ResumeLayout(False)
        Me.TbOppdaterKunde.PerformLayout()
        Me.tbKundeEpost.ResumeLayout(False)
        Me.tbKundeEpost.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.ToolStripEx11.ResumeLayout(False)
        Me.ToolStripEx11.PerformLayout()
        Me.ToolStripEx2.ResumeLayout(False)
        Me.ToolStripEx2.PerformLayout()
        Me.tbSalg.ResumeLayout(False)
        Me.tbSalg.PerformLayout()
        CType(Me.TabControlAdv2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv2.ResumeLayout(False)
        Me.tbTextEdit.ResumeLayout(False)
        Me.tbTextEdit.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ToolStripEx6.ResumeLayout(False)
        Me.ToolStripEx6.PerformLayout()
        Me.tbUtleieOversikt.ResumeLayout(False)
        CType(Me.GridDataBoundGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tbReporting.ResumeLayout(False)
        Me.ToolStripEx3.ResumeLayout(False)
        Me.ToolStripEx3.PerformLayout()
        Me.tbSettings.ResumeLayout(False)
        Me.tbSettings.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.tabSettings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabSettings.ResumeLayout(False)
        Me.TabPageAdv1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.PerformLayout()
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.Panel2.PerformLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        CType(Me.txtSvrPassRep, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSvrPass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TxtSvrUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSvrDB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtServer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.toolstripDBInfo.ResumeLayout(False)
        Me.toolstripDBInfo.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.ToolStripEx10.ResumeLayout(False)
        Me.ToolStripEx10.PerformLayout()
        CType(Me.dgvSQLQuery, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStripEx5.ResumeLayout(False)
        Me.ToolStripEx5.PerformLayout()
        Me.tbLager.ResumeLayout(False)
        Me.tbLager.PerformLayout()
        CType(Me.TabLager, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabLager.ResumeLayout(False)
        Me.TabPageAdv5.ResumeLayout(False)
        CType(Me.GridDataBoundGrid4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageAdv6.ResumeLayout(False)
        CType(Me.GridDataBoundGrid3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LagerRapportTrondheimBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Drift8_2016DataSetTrondheimLager, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageAdv7.ResumeLayout(False)
        CType(Me.GridDataBoundGrid2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LagerRapportStavangerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Drift8_2016DataSetLagerRapportStavnager, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageAdv2.ResumeLayout(False)
        Me.ToolStripEx4.ResumeLayout(False)
        Me.ToolStripEx4.PerformLayout()
        CType(Me.Drift82016DataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KundeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Drift82016dsSalgsRapportViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SalgsRaportBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SalgsRaportBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageAdv9.ResumeLayout(False)
        Me.SplitContainerAdv2.Panel1.ResumeLayout(False)
        Me.SplitContainerAdv2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainerAdv2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainerAdv2.ResumeLayout(False)
        CType(Me.TabControlAdv8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv8.ResumeLayout(False)
        Me.TabPageAdv10.ResumeLayout(False)
        CType(Me.GridDataBoundGrid5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TabControlAdv9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv9.ResumeLayout(False)
        Me.TabPageAdv13.ResumeLayout(False)
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer4.ResumeLayout(False)
        CType(Me.GridDataBoundGrid6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPageAdv14.ResumeLayout(False)
        Me.TabPageAdv14.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.StatusStripEx2.ResumeLayout(False)
        CType(Me.TabControlAdv7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControlAdv7.ResumeLayout(False)
        CType(Me.VisAnsattesSalgBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtSalgReportingBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents tbAnsKund As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents tbPersoner As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents tbSalg As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents tbLager As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents tbSettings As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents tabSettings As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents TabPageAdv1 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents ToolStripEx1 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents ToolStripEx2 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents TabControlAdv2 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents tbTextEdit As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents tbReporting As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents ToolStripEx3 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents ToolStripEx4 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents ToolStripEx5 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents tbUtleieOversikt As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Private WithEvents richTextBox1 As RichTextBox
    Friend WithEvents ToolStripEx6 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents NewToolStripButton As ToolStripButton
    Friend WithEvents OpenToolStripButton As ToolStripButton
    Friend WithEvents SaveToolStripButton As ToolStripButton
    Friend WithEvents PrintToolStripButton As ToolStripButton
    Friend WithEvents toolStripSeparator As ToolStripSeparator
    Friend WithEvents CutToolStripButton As ToolStripButton
    Friend WithEvents CopyToolStripButton As ToolStripButton
    Friend WithEvents PasteToolStripButton As ToolStripButton
    Friend WithEvents toolStripSeparator1 As ToolStripSeparator
    Friend WithEvents txtFontCombo As Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx
    Friend WithEvents txtFontSizeCombo As Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx
    Friend WithEvents FontListBox1 As Syncfusion.Windows.Forms.Tools.FontListBox
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents txtInsertImg As ToolStripButton
    Friend WithEvents txtUndo As ToolStripButton
    Friend WithEvents txtRedo As ToolStripButton
    Friend WithEvents ToolStripButton4 As ToolStripButton
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents txtAlignLeft As ToolStripButton
    Friend WithEvents txtAlignJust As ToolStripButton
    Friend WithEvents txtAlignRight As ToolStripButton
    Friend WithEvents GradientPanel1 As Syncfusion.Windows.Forms.Tools.GradientPanel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents GridDataBoundGrid1 As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents KjøpTableAdapter As drift8_2016DataSetTableAdapters.KjøpTableAdapter
    Private WithEvents drift8_2016DataSet As drift8_2016DataSet
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents toolstripDBInfo As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents tsBtnDBInfo As ToolStripButton
    Friend WithEvents lblSvrUser As Syncfusion.Windows.Forms.Tools.AutoLabel
    Friend WithEvents lblDB As Syncfusion.Windows.Forms.Tools.AutoLabel
    Friend WithEvents lblServer As Syncfusion.Windows.Forms.Tools.AutoLabel
    Friend WithEvents txtSvrPassRep As Syncfusion.Windows.Forms.Tools.TextBoxExt
    Friend WithEvents txtSvrPass As Syncfusion.Windows.Forms.Tools.TextBoxExt
    Friend WithEvents TxtSvrUser As Syncfusion.Windows.Forms.Tools.TextBoxExt
    Friend WithEvents txtSvrDB As Syncfusion.Windows.Forms.Tools.TextBoxExt
    Friend WithEvents txtServer As Syncfusion.Windows.Forms.Tools.TextBoxExt
    Friend WithEvents lblSvrPassRep As Syncfusion.Windows.Forms.Tools.AutoLabel
    Friend WithEvents lblSvrPass As Syncfusion.Windows.Forms.Tools.AutoLabel
    Friend WithEvents ButtonLeggTilLeie As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents tbOverview As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents ToolStripDropDownButton1 As ToolStripDropDownButton
    Friend WithEvents FrmLagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FrmSalgToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabControlAdv4 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents ToolStripEx7 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents reportLager As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents ToolStripEx8 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents reportLeie As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents Panel4 As Panel
    Friend WithEvents ToolStripEx10 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents Timer1 As Timer
    Friend WithEvents AnsattBindingSource As BindingSource
    Friend WithEvents AnsattTableAdapter As drift8_2016DataSetTableAdapters.AnsattTableAdapter
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TabControlAdv5 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents tbAnsatte As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents SplitContainerAdv1 As Syncfusion.Windows.Forms.Tools.SplitContainerAdv
    Friend WithEvents btnChngPW As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents btnAddUsr As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents dgvAnsatte As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents tbKunder As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents TabControlAdv1 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents tbKunderOversikt As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents tbKundeEpost As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents rtbKundeEpost As RichTextBox
    Friend WithEvents StatusStripEx1 As Syncfusion.Windows.Forms.Tools.StatusStripEx
    Friend WithEvents ToolStripEx11 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents NewToolStripButton1 As ToolStripButton
    Friend WithEvents OpenToolStripButton1 As ToolStripButton
    Friend WithEvents SaveToolStripButton1 As ToolStripButton
    Friend WithEvents PrintToolStripButton1 As ToolStripButton
    Friend WithEvents toolStripSeparator5 As ToolStripSeparator
    Friend WithEvents CutToolStripButton1 As ToolStripButton
    Friend WithEvents CopyToolStripButton1 As ToolStripButton
    Friend WithEvents PasteToolStripButton1 As ToolStripButton
    Friend WithEvents toolStripSeparator6 As ToolStripSeparator
    Friend WithEvents btnSendEpostKunde As ToolStripButton
    Friend WithEvents toolstripCMBxKunder As Syncfusion.Windows.Forms.Tools.ToolStripComboBoxEx
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents SpellChecker1 As Syncfusion.Text.SpellChecker
    Friend WithEvents ToolStripTxtSubject As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents ToolStripSplitButtonEx1 As Syncfusion.Windows.Forms.Tools.ToolStripSplitButtonEx
    Private WithEvents dtSalgReportingBindingSource As BindingSource
    Friend WithEvents StatusStripLabel1 As Syncfusion.Windows.Forms.Tools.StatusStripLabel
    Friend WithEvents StatusStripProgressBar1 As Syncfusion.Windows.Forms.Tools.StatusStripProgressBar
    Friend WithEvents StatusStripLabel2 As Syncfusion.Windows.Forms.Tools.StatusStripLabel
    Friend WithEvents FakturaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NyhetsbrevToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VareoversiktToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Private WithEvents KjøpBindingSource As BindingSource
    Friend WithEvents SalgsRaportTableAdapter As drift8_2016dsSalgsRapportViewTableAdapters.SalgsRaportTableAdapter
    Friend WithEvents SalgsRaportBindingSource1 As BindingSource
    Friend WithEvents Drift82016dsSalgsRapportViewBindingSource As BindingSource
    Private WithEvents VisAnsattesSalgBindingSource As BindingSource
    Private WithEvents drift8_2016dsSalgsRapportView As drift8_2016dsSalgsRapportView
    Private WithEvents SalgsRaportBindingSource2 As BindingSource
    Friend WithEvents Panel8 As Panel
    Friend WithEvents ReportViewer2 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents Panel9 As Panel
    Friend WithEvents ReportViewer3 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents KundeBindingSource As BindingSource
    Friend WithEvents KundeTableAdapter As drift8_2016DataSetTableAdapters.KundeTableAdapter
    Friend WithEvents btnAnsattUpdate As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TabLager As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents TabPageAdv5 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents A_LagerTableAdapter1 As drift8_2016DataSetTableAdapters.A_LagerTableAdapter
    Private WithEvents SalgsRaportBindingSource As BindingSource
    Friend WithEvents GridDataBoundGrid4 As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents TabPageAdv6 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents GridDataBoundGrid3 As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents TabPageAdv7 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents GridDataBoundGrid2 As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents SalgsRaportBindingSource3 As BindingSource
    Friend WithEvents Drift8_2016DataSetTrondheimLager As drift8_2016DataSetTrondheimLager
    Friend WithEvents LagerRapportTrondheimBindingSource As BindingSource
    Friend WithEvents LagerRapportTrondheimTableAdapter As drift8_2016DataSetTrondheimLagerTableAdapters.LagerRapportTrondheimTableAdapter
    Friend WithEvents LagerRapportALLETableAdapter As drift8_2016DataSetLageroversiktALLETableAdapters.LagerRapportALLETableAdapter
    Friend WithEvents Drift8_2016DataSetLagerRapportStavnager As drift8_2016DataSetLagerRapportStavnager
    Friend WithEvents LagerRapportStavangerBindingSource As BindingSource
    Friend WithEvents LagerRapportStavangerTableAdapter As drift8_2016DataSetLagerRapportStavnagerTableAdapters.LagerRapportStavangerTableAdapter
    Friend WithEvents btnUpdKunde As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents btnAddKunde As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents TabControlAdv6 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents TabPageAdv4 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents Drift82016DataSetBindingSource As BindingSource
    Friend WithEvents TabPageAdv9 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents SplitContainerAdv2 As Syncfusion.Windows.Forms.Tools.SplitContainerAdv
    Friend WithEvents ButtonAdv1 As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents ButtonAdv2 As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents ButtonAdv3 As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents TabControlAdv8 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents TabPageAdv10 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents GridDataBoundGrid5 As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents TabPageAdv11 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents TabPageAdv12 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents TabControlAdv9 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents TabPageAdv13 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents SplitContainer4 As SplitContainer
    Friend WithEvents ButtonAdv4 As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents ButtonAdv5 As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents GridDataBoundGrid6 As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents TabPageAdv14 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents RichTextBox2 As RichTextBox
    Friend WithEvents StatusStripEx2 As Syncfusion.Windows.Forms.Tools.StatusStripEx
    Friend WithEvents TabControlAdv7 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents tbKundeOversikt As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Friend WithEvents TabPageAdv15 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents dgvPrivatKunde As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents TabPageAdv16 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents dgvBedriftKunde As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents TbOppdaterKunde As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents btnOppdater As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents chkEpost As CheckBox
    Friend WithEvents chkEtternavn As CheckBox
    Friend WithEvents chkFornavn As CheckBox
    Friend WithEvents txtEpost As TextBox
    Friend WithEvents txtEtternavn As TextBox
    Friend WithEvents txtFornavn As TextBox
    Friend WithEvents txtKID As TextBox
    Friend WithEvents lblKID As Label
    Friend WithEvents btnOppdaterBedKunde As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents btnOppdaterPrivKunde As Syncfusion.Windows.Forms.ButtonAdv
    Friend WithEvents txtBedNavn As TextBox
    Friend WithEvents txtBedAdresse As TextBox
    Friend WithEvents chkBedNavn As CheckBox
    Friend WithEvents chkAdresse As CheckBox
    Friend WithEvents txtPrivAdresse As TextBox
    Friend WithEvents txtPostBed As TextBox
    Friend WithEvents txtPostPriv As TextBox
    Friend WithEvents chkPostNummer As CheckBox
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents ToolStripButton3 As ToolStripButton
    Friend WithEvents ToolStripButton5 As ToolStripButton
    Friend WithEvents rtbSQLQuery As RichTextBox
    Friend WithEvents ToolStripLabel3 As ToolStripLabel
    Friend WithEvents dgvSQLQuery As Syncfusion.Windows.Forms.Grid.GridDataBoundGrid
    Friend WithEvents ToolStripButton6 As ToolStripButton
    Friend WithEvents ToolStripButton7 As ToolStripButton
    Private WithEvents TabPageAdv3 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents ToolStripEx9 As Syncfusion.Windows.Forms.Tools.ToolStripEx
    Friend WithEvents ReportViewer4 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents TabPageAdv2 As Syncfusion.Windows.Forms.Tools.TabPageAdv
    Friend WithEvents ReportViewer5 As Microsoft.Reporting.WinForms.ReportViewer
    Private WithEvents Drift8_2016DataSetLageroversiktALLE As drift8_2016DataSetLageroversiktALLE
    Private WithEvents LagerRapportALLEBindingSource As BindingSource
    Private WithEvents TabControlAdv3 As Syncfusion.Windows.Forms.Tools.TabControlAdv
    Private WithEvents VisLeieBindingSource As BindingSource
    Friend WithEvents VisAktiveLeieTableAdapter As drift8_2016dsVisLeieRapportViewTableAdapters.VisAktiveLeieTableAdapter
    Private WithEvents VisAktiveLeieBindingSource As BindingSource
    Friend WithEvents drift8_2016dsVisLeieRapportView As drift8_2016dsVisLeieRapportView
    Friend WithEvents reportSalg As Syncfusion.Windows.Forms.Tools.TabPageAdv
End Class
